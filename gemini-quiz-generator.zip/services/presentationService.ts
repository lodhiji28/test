import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import PptxGenJS from "pptxgenjs";
import { Language, GeneratedPresentationData, SlideData, SlideType } from '../types';
import { GEMINI_MODEL_TEXT } from '../constants';

const parseGeminiPresentationResponse = (rawResponseText: string): GeneratedPresentationData => {
    let stringToParse = rawResponseText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = stringToParse.match(fenceRegex);

    if (match && match[2]) {
      stringToParse = match[2].trim();
    }
    
    stringToParse = stringToParse.replace(/,\s*\]/g, "]");
    stringToParse = stringToParse.replace(/,\s*\}/g, "}");

    try {
        const parsed = JSON.parse(stringToParse);
        if (!parsed.presentationTitle || typeof parsed.presentationTitle !== 'string' || !Array.isArray(parsed.slides)) {
            console.error("Invalid presentation data structure from AI:", parsed);
            throw new Error("AI response for presentation was valid JSON, but did not have the expected 'presentationTitle' (string) and 'slides' (array) structure.");
        }
        parsed.slides.forEach((slide: any, index: number) => {
            if (typeof slide.slideNumber !== 'number' ||
                typeof slide.slideTitle !== 'string' ||
                typeof slide.slideType !== 'string' ||
                !Array.isArray(slide.content)) { // content must be an array
                throw new Error(`Slide at index ${index} has an invalid structure (slideNumber, slideTitle, slideType, or content format).`);
            }
            // Further validation based on slideType
            if (slide.slideType === "QuestionSlide") {
                if (!Array.isArray(slide.options) || typeof slide.correctOptionIndex !== 'number') {
                    throw new Error(`QuestionSlide at index ${index} is missing 'options' array or 'correctOptionIndex' number.`);
                }
            }
        });
        return parsed as GeneratedPresentationData;
    } catch (e) {
        console.error("Failed to parse presentation JSON. Cleaned text:", stringToParse);
        console.error("Parsing error:", e);
        if (e instanceof SyntaxError) {
            throw new SyntaxError(`Failed to parse the AI's presentation response even after cleaning. Details: ${e.message}`);
        }
        throw e; // Re-throw other errors
    }
};

const handleGeminiPresentationApiError = (error: any, modelUsed: string): string => {
    console.error("Gemini API Error (Presentation Generation):", error);
    // ... (error handling logic remains largely the same as before, but messages can be more specific)
    let detailedMessage = "An unexpected error occurred while generating the presentation.";
     if (error instanceof SyntaxError) {
        detailedMessage = error.message.includes("even after cleaning") ? error.message : "Failed to parse the AI's response for the presentation. The data received was not valid JSON.";
    } else if (error instanceof Error) {
        // Handle specific error messages as before
        detailedMessage = `Error generating presentation with Gemini API: ${error.message}`;
    } else {
        detailedMessage = `Unknown error generating presentation with Gemini API: ${String(error)}`;
    }
    return detailedMessage;
};

export const generatePresentation = async (
  input: string,
  type: 'topic' | 'text',
  languageName: string,
  apiKey: string,
  customInstructionsP?: string // Renamed to avoid conflict
): Promise<void> => {
  if (!apiKey) {
    throw new Error("API Key is not provided for presentation service.");
  }
  const ai = new GoogleGenAI({ apiKey });
  const pres = new PptxGenJS();
  pres.layout = 'LAYOUT_WIDE';

  // Enhanced prompt:
  const prompt = `
    You are an expert AI specializing in creating educational presentations, like those used for current affairs or topic explanations.
    The user wants a presentation in ${languageName}.
    Input type: ${type}.
    Input content/topic: """${input}"""
    ${customInstructionsP ? `User's custom instructions for this presentation: """${customInstructionsP}"""` : ''}

    Please generate structured content for this presentation. The output MUST be a single, valid JSON object.
    This JSON object must contain:
    1.  "presentationTitle": A string for the main title of the presentation. This should be concise, engaging, and in ${languageName}.
    2.  "slides": An array of slide objects. Generate approximately 5-10 slides, depending on the depth of the input.

    Each slide object in the "slides" array MUST have the following properties:
    -   "slideNumber": An integer, starting from 1.
    -   "slideTitle": A string for the slide's title, in ${languageName}. Keep it brief and descriptive of the slide's content.
    -   "slideType": A string. Choose ONE from: "TitleSlide", "ContentSlide", "QuestionSlide", "ExplanationSlide", "SectionHeaderSlide", "ThankYouSlide".
    -   "content": An array of strings.
        -   For "TitleSlide": The first string can be a subtitle. If no subtitle, use an empty array or a brief introductory phrase.
        -   For "ContentSlide": Bullet points or short paragraphs (each as a string). Aim for 3-5 points.
        -   For "QuestionSlide": The question text as the first string.
        -   For "ExplanationSlide": The explanation text, broken into logical paragraphs if needed (each paragraph a string).
        -   For "SectionHeaderSlide": A brief description or title for the new section (as a single string in the array).
        -   For "ThankYouSlide": A short concluding message (e.g., ["Thank You!", "Questions?"]).
    -   "options" (OPTIONAL): For "QuestionSlide" ONLY. An array of 3 to 4 string options, in ${languageName}.
    -   "correctOptionIndex" (OPTIONAL): For "QuestionSlide" ONLY. A 0-based integer index of the correct option in the "options" array.
    -   "explanation" (OPTIONAL): For "QuestionSlide" or "ExplanationSlide". A detailed, educational explanation in ${languageName}. For questions, explain why the correct answer is right and, if appropriate, why others are wrong. This should be thorough.
    -   "notes" (OPTIONAL): A string for speaker notes (brief).

    CRITICAL GUIDELINES:
    -   All textual content (titles, subtitles, bullets, questions, options, explanations, notes) MUST be in ${languageName}.
    -   For "QuestionSlide", make the question clear, options distinct, and the explanation comprehensive and educational.
    -   Structure the presentation logically. Start with a title/intro, then content/Q&A, and end with a thank you/conclusion. Use "SectionHeaderSlide" for transitions if appropriate.
    -   The JSON output MUST be perfect. No trailing commas, no comments, no markdown. Strictly a single JSON object.

    Example for one "QuestionSlide" (if language was English):
    {
      "slideNumber": 3,
      "slideTitle": "Quiz: Key Event",
      "slideType": "QuestionSlide",
      "content": ["What was the primary outcome of Event X?"],
      "options": ["Outcome A", "Outcome B", "Outcome C", "Outcome D"],
      "correctOptionIndex": 1,
      "explanation": "Outcome B is correct because [detailed reasoning based on facts]. Option A is incorrect because [...]. Option C is incorrect due to [...]. Option D is not relevant because [...].",
      "notes": "Emphasize the long-term impact of Outcome B."
    }

    Output ONLY the JSON object.
  `;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: GEMINI_MODEL_TEXT,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            temperature: 0.65, // Slightly lower for more factual, structured output
        }
    });

    const presentationData = parseGeminiPresentationResponse(response.text);

    // --- Define Master Slides ---
    // The type for objects on a master slide is not strongly typed in pptxgenjs definitions,
    // so we let TypeScript infer it, which is compatible with the expected type.
    const slideMasterPropsBase = {
        title: '', // Will be set per master
        background: { color: "F1F5F9" }, // Light Slate background
        slideNumber: { x: 0.3, y: "92%", color: "6B7280", fontSize: 10, bold:true },
        objects: [
            { rect: { x: 0.0, y: "90%", w: "100%", h: 0.05, fill: { color: "007ACC" } } }, // Blue accent line at bottom
            // FIX: Wrapping the text properties object in an array to match the `TextProps[]` type, which helps TypeScript resolve the union type correctly.
            { text: [{ text: presentationData.presentationTitle, options: { x: "40%", y: "92%", w: "58%", align: "right", color: "6B7280", fontSize: 10, italic: true } }] },
        ],
    };

    pres.defineSlideMaster({
        ...slideMasterPropsBase,
        title: 'TITLE_MASTER',
        objects: [
            ...slideMasterPropsBase.objects!,
            // FIX: Use `as const` on placeholder types to ensure they are treated as literal types, not the general `string` type.
            { placeholder: { options: { name: "title", type: "title" as const, x: 0.5, y: 1.5, w: 9, h: 1.5 }, text: "Title Placeholder" } },
            { placeholder: { options: { name: "subtitle", type: "body" as const, x: 0.5, y: 3.2, w: 9, h: 1.0 }, text: "Subtitle Placeholder" } },
        ],
    });
    
    pres.defineSlideMaster({
        ...slideMasterPropsBase,
        title: 'CONTENT_MASTER',
        objects: [
            ...slideMasterPropsBase.objects!,
            { placeholder: { options: { name: "title", type: "title" as const, x: 0.4, y: 0.2, w: 9.2, h: 0.8 }, text: "Slide Title Placeholder" } },
            // FIX: Cast options to `any` because `autoFit` is a valid pptxgenjs property but is missing from the type definition for placeholders.
            { placeholder: { options: { name: "body", type: "body" as const, x: 0.4, y: 1.0, w: 9.2, h: 5.0, autoFit:true, fontSize:18 } as any, text: "Body Placeholder" } },
        ],
    });

    pres.defineSlideMaster({ // For Q&A slides
        ...slideMasterPropsBase,
        title: 'QA_MASTER',
        objects: [
             ...slideMasterPropsBase.objects!,
            { placeholder: { options: { name: "title", type: "title" as const, x: 0.4, y: 0.2, w: 9.2, h: 0.7 }, text: "Question Title" } },
            { placeholder: { options: { name: "question", type: "body" as const, x: 0.4, y: 0.9, w: 9.2, h: 1.0, fontSize: 20, bold: true }, text: "Question Text" } },
            // FIX: Cast options to `any` because `autoFit` is a valid pptxgenjs property but is missing from the type definition for placeholders.
            { placeholder: { options: { name: "options", type: "body" as const, x: 0.4, y: 2.0, w: 9.2, h: 2.0, fontSize: 16, autoFit:true } as any, text: "Options Area" } },
            // FIX: Cast options to `any` because `autoFit` is a valid pptxgenjs property but is missing from the type definition for placeholders.
            { placeholder: { options: { name: "explanation", type: "body" as const, x: 0.4, y: 4.1, w: 9.2, h: 2.0, fontSize: 14, autoFit:true, color: "4B5563" } as any, text: "Explanation Area" } },
        ],
    });
     pres.defineSlideMaster({
        ...slideMasterPropsBase,
        title: 'SECTION_MASTER',
        background: { color: "007ACC" }, // Blue background for section headers
        objects: [
            // Override footer for section master for better contrast
            { rect: { x: 0.0, y: "90%", w: "100%", h: 0.05, fill: { color: "FFFFFF" } } },
             // FIX: Wrapping the text properties object in an array to match the `TextProps[]` type, which helps TypeScript resolve the union type correctly.
             { text: [{ text: presentationData.presentationTitle, options: { x: "40%", y: "92%", w: "58%", align: "right", color: "E5E7EB", fontSize: 10, italic: true } }] },
            { placeholder: { options: { name: "title", type: "title" as const, x: 0.5, y: 2.5, w: 9, h: 1.5, align:"center",fontFace:"Arial Black" }, text: "Section Title Placeholder" } },
        ],
         slideNumber: { x: 0.3, y: "92%", color: "E5E7EB", fontSize: 10, bold:true },
    });


    // --- Generate Slides ---
    presentationData.slides.forEach((slide, index) => {
      let pptxSlide;
      const slideTitleOpts = { placeholder: "title", text: slide.slideTitle, options: {color: "003366"} };

      switch (slide.slideType) {
        case "TitleSlide":
          pptxSlide = pres.addSlide({ masterName: 'TITLE_MASTER' });
          pptxSlide.addText([ {text:slide.slideTitle, options:{fontSize:40, bold:true, color:"003366"}}, 
                               ...(slide.content.length > 0 ? [{text:slide.content[0], options:{fontSize:24, color:"4A4A4A", breakLine:true}}] : []) ], 
                            { placeholder: "title" }); // Using title placeholder for main text
          break;
        case "ContentSlide":
          pptxSlide = pres.addSlide({ masterName: 'CONTENT_MASTER' });
          pptxSlide.addText(slide.slideTitle, { placeholder: "title", options:{color:"00509E"} });
          pptxSlide.addText(
            slide.content.map(point => ({ text: point, options: { bullet: { code: "25CF" }, fontSize: 18, color:"333333", paraSpaceAfter:8 } })),
            { placeholder: "body" }
          );
          break;
        case "QuestionSlide":
          pptxSlide = pres.addSlide({ masterName: 'QA_MASTER' });
          pptxSlide.addText(slide.slideTitle, { placeholder: "title", options:{color:"00509E", fontSize:24} });
          pptxSlide.addText(slide.content[0], { placeholder: "question" });
          
          let optionTexts: PptxGenJS.TextProps[] = [];
          if (slide.options) {
            optionTexts = slide.options.map((opt, idx) => ({
              text: `${String.fromCharCode(65 + idx)}. ${opt}`,
              options: {
                color: (idx === slide.correctOptionIndex) ? "006400" : "4F4F4F", // Dark Green for correct, Dark Gray for others
                bold: (idx === slide.correctOptionIndex),
                breakLine: true,
                paraSpaceAfter: 5,
              }
            }));
          }
          pptxSlide.addText(optionTexts, { placeholder: "options" });
          if (slide.explanation) {
            pptxSlide.addText([{text:"Explanation:", options:{bold:true, color:"2c5282", breakLine:true}}, {text:slide.explanation, options:{italic:true}}], { placeholder: "explanation" });
          }
          break;
        case "ExplanationSlide":
            pptxSlide = pres.addSlide({ masterName: 'CONTENT_MASTER' });
            pptxSlide.addText(slide.slideTitle, { placeholder: "title", options:{color:"00509E", fontSize:22} });
            pptxSlide.addText(
                slide.content.map(paragraph => ({ text: paragraph, options: { fontSize: 16, color:"333333", paraSpaceAfter:10 } })),
                { placeholder: "body" }
            );
            break;
        case "SectionHeaderSlide":
            pptxSlide = pres.addSlide({ masterName: 'SECTION_MASTER' });
            pptxSlide.addText(slide.slideTitle, { placeholder: "title", options:{color:"FFFFFF", fontSize:44, bold:true} });
            break;
        case "ThankYouSlide":
            pptxSlide = pres.addSlide({ masterName: 'TITLE_MASTER' }); // Reuse title master for simplicity
            pptxSlide.addText(slide.slideTitle, { placeholder:"title", options:{align:"center", fontSize:40, color:"003366"}});
            if (slide.content.length > 0) {
                 pptxSlide.addText(slide.content[0], { placeholder:"subtitle", options:{align:"center", fontSize:20, color:"4A4A4A"} });
            }
            break;
        default:
          console.warn(`Unknown slide type: ${slide.slideType}. Using CONTENT_MASTER.`);
          pptxSlide = pres.addSlide({ masterName: 'CONTENT_MASTER' });
          pptxSlide.addText(slide.slideTitle, { placeholder: "title" });
          pptxSlide.addText(slide.content.join('\n'), { placeholder: "body" });
          break;
      }
      if(slide.notes && pptxSlide) {
        pptxSlide.addNotes(slide.notes);
      }
      // Ensure slide number is correctly applied from master if not overridden
      if (pptxSlide && !slideMasterPropsBase.slideNumber) { // Only add if master doesn't handle it (though it should)
          pptxSlide.addText((index + 1).toString(), { x: "90%", y: "92%", w: "8%", h:0.5, fontSize:10, color:"6B7280", align:"right"});
      }
    });

    const sanitizedTitle = presentationData.presentationTitle.replace(/[^\w\s]/gi, '').replace(/\s+/g, '_') || 'presentation';
    pres.writeFile({ fileName: `${sanitizedTitle}.pptx` });

  } catch (error) {
    console.error("Error in generatePresentation function:", error);
    const errorMessage = handleGeminiPresentationApiError(error, GEMINI_MODEL_TEXT);
    throw new Error(errorMessage);
  }
};
