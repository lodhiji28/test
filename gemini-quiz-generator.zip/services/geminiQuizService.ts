

import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Question, GeneratedQuizData } from '../types';
import { GEMINI_MODEL_TEXT } from '../constants';

const parseGeminiResponse = (rawResponseText: string): any => {
    let stringToParse = rawResponseText.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = stringToParse.match(fenceRegex);

    if (match && match[2]) {
      stringToParse = match[2].trim();
    }
    
    // Attempt to clean common JSON issues, like trailing commas
    // Remove trailing commas from arrays
    stringToParse = stringToParse.replace(/,\s*\]/g, "]");
    // Remove trailing commas from objects
    stringToParse = stringToParse.replace(/,\s*\}/g, "}");

    // Sanitize escaped newlines within strings if they are causing issues
    // This is a more aggressive cleaning step and might be needed if newlines are not properly escaped by the AI
    // stringToParse = stringToParse.replace(/\\n/g, "\\\\n"); // Example, might need adjustment

    try {
        return JSON.parse(stringToParse);
    } catch (e) {
        console.error("Failed to parse cleaned JSON. Original text (after fence stripping):", stringToParse);
        console.error("Parsing error:", e);
        // Re-throw the original error type or a custom one if preferred
        if (e instanceof SyntaxError) {
            throw new SyntaxError(`Failed to parse the AI's response even after cleaning. The data received was not valid JSON. Details: ${e.message}`);
        }
        throw e;
    }
};

const validateAndFormatQuestions = (parsedData: any, expectedCount: number): GeneratedQuizData => {
    if (!parsedData || typeof parsedData.quizTitle !== 'string' || !Array.isArray(parsedData.questions) || parsedData.questions.length === 0) {
      console.error("API Response (after parsing but before validation):", parsedData);
      throw new Error("API response was valid JSON, but did not have the expected 'quizTitle' (string) and 'questions' (array of at least one question) structure.");
    }

    const questions: Question[] = parsedData.questions.map((q: any, index: number) => {
      const text = typeof q.text === 'string' ? q.text : `Question ${index + 1} (text missing)`;
      const options = Array.isArray(q.options) && q.options.length === 4 && q.options.every((opt: any) => typeof opt === 'string') 
                      ? q.options 
                      : ["Option A (default)", "Option B (default)", "Option C (default)", "Option D (default)"];
      const correctIndex = typeof q.correctIndex === 'number' && q.correctIndex >= 0 && q.correctIndex < 4 
                           ? q.correctIndex 
                           : 0;
      const explanation = typeof q.explanation === 'string' ? q.explanation : "No explanation provided.";
      
      return {
        id: index,
        text: text,
        options: options,
        correctIndex: correctIndex,
        explanation: explanation,
        reference: q.reference || "",
      };
    });
    
    // If the AI returns more questions than requested, slice it. If fewer, it's handled by the initial check.
    // This is a safeguard. Ideally, the AI respects the count.
    const finalQuestions = questions.slice(0, expectedCount);


    return { quizTitle: parsedData.quizTitle, questions: finalQuestions };
};

const handleGeminiApiError = (error: any, modelUsed: string): string => {
    console.error("Gemini API Error Details:", error); 

    let detailedMessage = "An unexpected error occurred while fetching questions.";

    if (error instanceof SyntaxError) {
        // Check if the message already indicates cleaning was attempted
        if (error.message.includes("even after cleaning")) {
            detailedMessage = error.message; // Use the more specific message from parseGeminiResponse
        } else {
            detailedMessage = "Failed to parse the AI's response. The data received was not valid JSON. This can happen if the AI's output is malformed. Please try again. If the issue persists, the AI model might be temporarily unavailable or returning an unexpected format.";
        }
    } else if (error instanceof Error) {
        const lowerCaseErrorMessage = error.message.toLowerCase();
        if (lowerCaseErrorMessage.includes("permission_denied") || lowerCaseErrorMessage.includes("403")) {
            detailedMessage = "API Permission Denied (Error 403): Unable to generate questions.\nPlease check the following for your Google Cloud project:\n1. API Key: Ensure it's correct and active.\n2. IAM Permissions: The key's service account or your user account needs a role like 'Vertex AI User' or 'Generative Language API User'.\n3. API Enabled: Verify the 'Generative Language API' (or Vertex AI API) is enabled.\n4. Billing: Confirm billing is active and correctly linked to the project.";
        } else if (lowerCaseErrorMessage.includes("quota") || lowerCaseErrorMessage.includes("resource_exhausted") || lowerCaseErrorMessage.includes("429")) {
            detailedMessage = "API Quota Exceeded or Resource Exhausted: Failed to generate questions. Please check your Gemini API usage, quotas, and limits in the Google Cloud console, or try again later.";
        } else if (lowerCaseErrorMessage.includes("api key not valid") || lowerCaseErrorMessage.includes("invalid api key") || lowerCaseErrorMessage.includes("401")) {
            detailedMessage = "Invalid API Key (Error 401): The provided API key is not valid or not authorized. Please ensure the API_KEY environment variable is set correctly with a valid key.";
        } else if (lowerCaseErrorMessage.includes("model_not_found") || lowerCaseErrorMessage.includes("404")) {
            detailedMessage = `API Model Not Found (Error 404): The model '${modelUsed}' might be unavailable or incorrectly specified. Please check the model name.`;
        } else if (lowerCaseErrorMessage.includes("did not have the expected 'quiztitle'")) { 
             detailedMessage = "The AI's response was valid JSON, but it did not match the expected structure (missing 'quizTitle' or 'questions'). The AI might have provided an incomplete or differently formatted response. Please try again.";
        } else if (lowerCaseErrorMessage.includes("billing") || lowerCaseErrorMessage.includes("account disabled")) {
            detailedMessage = "Billing Issue: There might be a problem with the billing account associated with your project, or the account may be disabled. Please check your Google Cloud billing status."
        }
        // Specific error for large text that might be caught by Gemini's safety or other internal limits
        else if (lowerCaseErrorMessage.includes("candidate data was blocked") || lowerCaseErrorMessage.includes("finish reason: safety") || lowerCaseErrorMessage.includes("prompt was blocked") || lowerCaseErrorMessage.includes("input was blocked")) {
            detailedMessage = "The provided text or instructions may have triggered a safety filter or exceeded content limits. Please try modifying the text or reducing its length. If the issue persists, ensure the content adheres to Google's safety guidelines.";
        } else if (lowerCaseErrorMessage.includes("invalid content")) {
             detailedMessage = "The AI model reported invalid content in the request, possibly due to the length or nature of the pasted text. Please try shortening or revising the text.";
        }
        else {
            detailedMessage = `An error occurred while communicating with the Gemini API: ${error.message}`;
        }
    } else {
        detailedMessage = `An unknown error occurred with the Gemini API: ${String(error)}`;
    }
    return detailedMessage;
};


export const generateQuestions = async (topic: string, count: number, apiKey: string, languageName: string): Promise<GeneratedQuizData> => {
  if (!apiKey) {
    throw new Error("API Key is not provided to geminiQuizService.");
  }
  const ai = new GoogleGenAI({ apiKey });

  const prompt = `Based on the user-provided topic: '${topic}', first, determine a concise and relevant 'quizTitle' for a quiz on this subject. The 'quizTitle' MUST be in ${languageName}.
Then, generate ${count} multiple-choice quiz questions about this topic, also in ${languageName}.
Each question should be unique and test different aspects of the topic.
All parts of each question (the 'text', each string in 'options', and the 'explanation') MUST be strictly in ${languageName}.

CRITICAL INSTRUCTION FOR QUESTION DIFFICULTY:
The ${count} questions MUST adhere to the following approximate difficulty distribution:
- 60-70% of questions should be Easy level (testing basic knowledge, straightforward recall).
- 20-30% of questions should be Moderate level (requiring some inference, application of concepts, or deeper understanding).
- 10-15% of questions should be Difficult level (challenging, potentially requiring synthesis of multiple pieces of information, or nuanced understanding).

Return the response as a single JSON object containing two top-level keys:
1.  'quizTitle': A string representing the concise title for the quiz, in ${languageName}.
2.  'questions': An array of ${count} question objects.

For each question object in the 'questions' array, provide the following:
a.  'text': The question string, in ${languageName}. The question text must be clean and should NOT start with any kind of prefix or classification tag like '[] General : ', '[] Idiom : ', etc.
b.  'options': An array of EXACTLY 4 string options, each in ${languageName}. Exactly one option must be correct. Ensure options are distinct and plausible. The format for this array MUST be precisely: ["string_option_1", "string_option_2", "string_option_3", "string_option_4"]. It is CRITICAL that there is NO comma after the fourth string option (i.e., after "string_option_4") before the closing square bracket ']'.
c.  'correctIndex': A 0-based integer index indicating the correct option in the 'options' array.
d.  'explanation': A detailed and comprehensive explanation, in ${languageName}, for why the correct answer is correct. Where appropriate, also explain why the other options are incorrect. The explanation should be structured clearly, possibly using bullet points or short, numbered paragraphs for better readability and understanding. It must be purely educational, factual, and directly related to the topic '${topic}'. Avoid conversational filler (e.g., "As you can see...", "The text explains that..."), promotional language, or external non-academic references unless absolutely essential and cited. For vocabulary-related questions, etymology can be included if relevant (etymology can be in English or the language of origin, but the main explanation text must be in ${languageName}).

Ensure the entire output is ONLY a valid JSON object. All string values (including 'quizTitle', question 'text', 'options', and 'explanation') must be purely informational and directly relevant to the quiz content. Do not include any conversational filler, introductory/concluding remarks outside of the defined JSON values, or promotional material.
This means:
- It must start with '{' and end with '}'.
- All keys and string values must be enclosed in double quotes.
- Commas must correctly separate elements in arrays and key-value pairs in objects.
- Crucially, there must be NO TRAILING COMMAS after the last element in any array or the last key-value pair in any object. For example, an array of strings should be ["a", "b"] and NOT ["a", "b",]. An object should be {"key1": "value1", "key2": "value2"} and NOT {"key1": "value1", "key2": "value2",}.
- Do not include any other text, introductory phrases, or markdown formatting like \\\`\\\`\\\`json ... \\\`\\\`\\\` outside of the JSON object itself.

Example of the full JSON object structure (if ${languageName} were English and topic was 'French History'):
{
  "quizTitle": "Quiz on French History",
  "questions": [
    {
      "text": "What is the capital of France?",
      "options": ["Berlin", "Madrid", "Paris", "Rome"],
      "correctIndex": 2,
      "explanation": "Paris is the capital and most populous city of France. It is located on the Seine River, in northern France, at the heart of the Île-de-France region.\\n\\nWhy other options are incorrect:\\n- Berlin is the capital of Germany.\\n- Madrid is the capital of Spain.\\n- Rome is the capital of Italy."
    }
    // If there were more questions, a comma would be here before the next question object,
    // but NO comma after the last question object in the 'questions' array.
    // Similarly, the 'options' array ["Berlin", "Madrid", "Paris", "Rome"] has no trailing comma.
  ]
}
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: GEMINI_MODEL_TEXT,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            temperature: 0.7, 
        }
    });
    
    const parsedData = parseGeminiResponse(response.text);
    return validateAndFormatQuestions(parsedData, count);

  } catch (error) {
    throw new Error(handleGeminiApiError(error, GEMINI_MODEL_TEXT));
  }
};


export const generateQuestionsFromText = async (
  pastedText: string,
  customInstructions: string,
  count: number,
  apiKey: string,
  languageName: string
): Promise<GeneratedQuizData> => {
  if (!apiKey) {
    throw new Error("API Key is not provided to geminiQuizService.");
  }
  const ai = new GoogleGenAI({ apiKey });

  let instructionPart = `You are an expert quiz generation AI. Your task is to create a mock test from the user-provided text.
First, analyze the provided text thoroughly to understand its main subjects, themes, and key information.
Based on this analysis, generate a concise and relevant 'quizTitle' for the quiz. The 'quizTitle' MUST be in ${languageName}.
Then, generate exactly ${count} multiple-choice quiz questions. All parts of each question (the 'text' of the question itself, each string in the 'options' array, and the 'explanation') MUST be strictly in ${languageName}.
The questions and their components (options, explanation) MUST be derived *directly and exclusively* from the content of the provided text. Do not introduce external knowledge.

CRITICAL INSTRUCTION FOR QUESTION DIFFICULTY (based on the provided text):
The ${count} questions MUST adhere to the following approximate difficulty distribution:
- 60-70% of questions should be Easy level (testing basic knowledge, straightforward recall from the text).
- 20-30% of questions should be Moderate level (requiring some inference from the text, application of concepts found in the text, or deeper understanding of text portions).
- 10-15% of questions should be Difficult level (challenging, potentially requiring synthesis of multiple pieces of information from the text, or nuanced understanding of the text).

For each question object in the 'questions' array, provide the following:
a.  'text': The question string, in ${languageName}. The question text must be clean and should NOT start with any kind of prefix or classification tag.
b.  'options': An array of EXACTLY 4 string options, each in ${languageName}. Exactly one option must be correct. Ensure options are distinct, plausible, and based on the text. The format for this array MUST be precisely: ["string_option_1", "string_option_2", "string_option_3", "string_option_4"]. It is CRITICAL that there is NO comma after the fourth string option (i.e., after "string_option_4") before the closing square bracket ']'.
c.  'correctIndex': A 0-based integer index indicating the correct option in the 'options' array.
d.  'explanation': A detailed and comprehensive explanation, in ${languageName}, for why the correct answer is correct, based *strictly and exclusively* on the provided text. Where appropriate and supported by the text, also explain why the other options are incorrect, citing evidence or reasoning directly from the provided text. The explanation should be structured clearly (e.g., using bullet points, numbered lists, or distinct points). It must be purely educational and factual. Avoid any information not present in the provided text, conversational filler (e.g., "The provided material shows..."), or promotional language. If possible, reference specific phrases or sentences from the text that support the answer.

Return the response as a single JSON object containing two top-level keys:
1.  'quizTitle': A string representing the concise title for the quiz, in ${languageName}, derived from the text's content.
2.  'questions': An array of exactly ${count} question objects. Ensure you provide exactly this many questions.

Ensure the entire output is ONLY a valid JSON object. All string values (including 'quizTitle', question 'text', 'options', and 'explanation') must be purely informational and directly relevant to the quiz content and the provided text. Do not include any conversational filler, introductory/concluding remarks outside of the defined JSON values, or promotional material.
This means:
- It must start with '{' and end with '}'.
- All keys and string values must be enclosed in double quotes.
- Commas must correctly separate elements in arrays and key-value pairs in objects.
- Crucially, there must be NO TRAILING COMMAS after the last element in any array or the last key-value pair in any object. For example, an array of strings should be ["a", "b"] and NOT ["a", "b",]. An object should be {"key1": "value1", "key2": "value2"} and NOT {"key1": "value1", "key2": "value2",}.
- Do not include any other text, introductory phrases, or markdown formatting like \\\`\\\`\\\`json ... \\\`\\\`\\\` outside of the JSON object itself.
The user-provided text to analyze is below, enclosed in triple single quotes.
`;

  if (customInstructions && customInstructions.trim() !== "") {
    instructionPart += `\n\nVERY IMPORTANT USER-SPECIFIC INSTRUCTIONS: The user has provided specific instructions for this mock test generation. Please adhere to them strictly: "${customInstructions}". If these instructions conflict with general guidelines, prioritize the user's specific instructions where possible, especially regarding question style or focus, while still deriving content from the provided text and maintaining the JSON output format and the high quality explanation standards.`;
  }

  const fullPrompt = `${instructionPart}\n\n'''${pastedText}'''`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_TEXT,
      contents: fullPrompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.6, // Slightly lower temperature for more factual generation from text
      }
    });

    const parsedData = parseGeminiResponse(response.text);
    return validateAndFormatQuestions(parsedData, count);

  } catch (error) {
    throw new Error(handleGeminiApiError(error, GEMINI_MODEL_TEXT));
  }
};
