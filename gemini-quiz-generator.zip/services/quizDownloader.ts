import { Question, Language } from '../types';
import { INSTRUCTION_STRINGS, SUPPORTED_LANGUAGES } from '../constants';

export const downloadQuizAsHtml = (
  quizTitle: string, 
  questions: Question[],
  totalTimeInSeconds: number,
  negativeMarking: number,
  appName: string,
  youtubeLink: string,
  telegramLink: string,
  language: Language
): void => {
  // Replace characters that are invalid in most filesystems, but keep the original title as much as possible.
  const sanitizedTitle = quizTitle.replace(/[<>:"\/\\|?*]/g, '_');
  const filename = `${sanitizedTitle}.html`;
  const htmlContent = generateQuizHtml(quizTitle, questions, totalTimeInSeconds, negativeMarking, appName, youtubeLink, telegramLink, language);
  
  const blob = new Blob([htmlContent], { type: 'text/html' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(a.href);
};

const generateQuizHtml = (
  quizTitle: string, 
  questions: Question[],
  totalTimeInSeconds: number,
  negativeMarking: number,
  appName: string,
  youtubeLink: string,
  telegramLink: string,
  language: Language
): string => {
  
  const instructionStrings = INSTRUCTION_STRINGS[language];
  const languageDetails = SUPPORTED_LANGUAGES.find(l => l.code === language) || SUPPORTED_LANGUAGES[0];
  const totalTimeMinutes = Math.floor(totalTimeInSeconds / 60);

  // Pre-render strings from functions to avoid embedding functions in JSON
  const finalInstructionStrings = {
    screenTitle: instructionStrings.screenTitle,
    quizNamePrefix: instructionStrings.quizNamePrefix,
    totalTime: instructionStrings.totalTime(totalTimeMinutes),
    totalMarks: instructionStrings.totalMarks(questions.length),
    instructionsHeader: instructionStrings.instructionsHeader,
    instruction1: instructionStrings.instruction1(questions.length),
    instruction2: instructionStrings.instruction2,
    instruction3: instructionStrings.instruction3(totalTimeMinutes),
    instruction4: instructionStrings.instruction4(negativeMarking),
    instruction5: instructionStrings.instruction5,
    instruction6: instructionStrings.instruction6,
    instruction7: instructionStrings.instruction7,
    defaultLangMessage: instructionStrings.defaultLangMessage(languageDetails.nativeName),
    defaultLangDisclaimer: instructionStrings.defaultLangDisclaimer,
    agreeCheckboxLabel: instructionStrings.agreeCheckboxLabel,
    proceedButton: instructionStrings.proceedButton,
    backButton: instructionStrings.backButton,
  };

  const questionsJson = JSON.stringify(questions);
  const quizTitleJson = JSON.stringify(quizTitle);
  const totalTimeJson = JSON.stringify(totalTimeInSeconds);
  const negativeMarkingJson = JSON.stringify(negativeMarking);
  const appNameJson = JSON.stringify(appName);
  const youtubeLinkJson = JSON.stringify(youtubeLink);
  const telegramLinkJson = JSON.stringify(telegramLink);
  const instructionStringsJson = JSON.stringify(finalInstructionStrings);
  const languageJson = JSON.stringify(language);


  return `
    <!DOCTYPE html>
    <html lang="${language}">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${appName} | ${quizTitle}</title>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
      <style>
        :root {
            --primary-color: #4361ee;
            --primary-dark: #3a56d4;
            --color-correct: #28a745;
            --color-incorrect: #dc3545;
            --color-unattempted: #ffc107;
            --color-marked: #805ad5; 
            --color-not-answered: #c53030;
            --color-answered: #2f855a;
            --color-answered-marked: #2c5282;

            --bg-correct: #f0fff4;
            --bg-incorrect: #fff5f5;
            --bg-unattempted: #fffff0;
            --bg-marked: #faf5ff;
            --bg-not-answered: #fed7d7;
            --bg-answered: #c6f6d5;
            --bg-answered-marked: #bee3f8;
            --bg-not-visited: #edf2f7;

            --border-correct: #9ae6b4;
            --border-incorrect: #feb2b2;
            --border-unattempted: #fefcbf;
            --border-marked: #e9d8fd;
            --border-not-answered: #f56565;
            --border-answered: #68d391;
            --border-answered-marked: #90cdf4;
            --border-not-visited: #e2e8f0;
            
            --shadow-sm: 0 1px 2px 0 rgba(0,0,0,0.05);
            --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -2px rgba(0,0,0,0.05);
            --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);

            --sidebar-width: 320px;
        }

        *, *::before, *::after { box-sizing: border-box; }

        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            background-color: #f0f4f8;
            color: #2d3748;
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        .hidden { display: none !important; }

        .app-container {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 1rem;
        }

        .card {
            background-color: white;
            border-radius: 1rem;
            box-shadow: var(--shadow-xl);
            overflow: hidden;
            width: 100%;
        }

        /* --- Instructions Screen --- */
        .instructions-card { max-width: 800px; }
        .instructions-content { padding: 2rem; }
        .instructions-content h1 {
            font-size: 2rem;
            font-weight: 700;
            text-align: center;
            color: #1a202c;
            margin-bottom: 1.5rem;
        }
        .instructions-summary {
            background-color: #edf2f7;
            padding: 1rem;
            border-radius: 0.5rem;
            border: 1px solid #e2e8f0;
            margin-bottom: 1.5rem;
        }
        .instructions-list {
            list-style: none;
            padding-left: 0;
            margin-bottom: 1.5rem;
        }
        .instructions-list li {
            padding-left: 1.5rem;
            position: relative;
            margin-bottom: 0.5rem;
        }
        .instructions-list li::before {
            content: '✔';
            position: absolute;
            left: 0;
            color: var(--primary-color);
        }
        .instructions-actions {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }
        @media(min-width: 640px) {
           .instructions-actions {
                flex-direction: row;
                justify-content: space-between;
           }
        }
        .btn {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 0.5rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        .btn-primary { background-color: var(--primary-color); color: white; }
        .btn-primary:hover { background-color: var(--primary-dark); }
        .btn:disabled { opacity: 0.6; cursor: not-allowed; }
        .btn-secondary { background-color: #e2e8f0; color: #4a5568; }
        .btn-secondary:hover { background-color: #cbd5e0; }

        /* --- Quiz Screen --- */
        .quiz-container {
            display: flex;
            flex-direction: column;
            width: 100%;
            height: 100vh;
            max-height: 100vh;
            max-width: 1600px;
        }
        .quiz-container.fullscreen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 9999;
            border-radius: 0;
        }

        .quiz-top-bar {
            background-color: var(--primary-color);
            color: white;
            padding: 0.75rem 1rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: var(--shadow-md);
            z-index: 10;
        }
        .quiz-top-bar h1 { font-size: 1.125rem; font-weight: 600; margin: 0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .top-bar-controls { display: flex; align-items: center; gap: 1rem; }
        .timer-display { background-color: rgba(255,255,255,0.2); padding: 0.25rem 0.75rem; border-radius: 999px; display: flex; align-items: center; gap: 0.5rem; }
        .control-btn { background: none; border: none; color: white; cursor: pointer; padding: 0.25rem; }
        .control-btn svg { width: 1.25rem; height: 1.25rem; }

        .quiz-main-area {
            display: flex;
            flex-grow: 1;
            overflow: hidden;
            position: relative;
        }
        .question-pane {
            flex-grow: 1;
            padding: 1.5rem;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
        }
        .question-header {
            background-color: #edf2f7;
            padding: 0.75rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
        }
        .question-text { font-size: 1.125rem; font-weight: 600; margin-bottom: 1.5rem; }
        .options-grid { display: flex; flex-direction: column; gap: 0.75rem; }
        .option-btn {
            text-align: left;
            padding: 0.75rem 1rem;
            border: 2px solid #e2e8f0;
            border-radius: 0.5rem;
            background-color: white;
            transition: all 0.2s ease-in-out;
            cursor: pointer;
            width: 100%;
            display: flex;
            align-items: flex-start;
        }
        .option-btn:hover { border-color: var(--primary-color); background-color: #f7fafc; }
        .option-btn.selected {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-dark);
            font-weight: 600;
        }
        .option-btn.correct { background-color: var(--bg-correct); border-color: var(--border-correct); color: var(--color-answered); }
        .option-btn.incorrect { background-color: var(--bg-incorrect); border-color: var(--border-incorrect); color: var(--color-not-answered); }
        .option-btn .option-prefix {
            font-weight: 600;
            margin-right: 0.5rem;
            color: var(--primary-color);
        }
        .option-btn.selected .option-prefix { color: white; }

        .question-actions {
            margin-top: auto;
            padding-top: 1rem;
            border-top: 1px solid #e2e8f0;
            display: grid;
            grid-template-columns: 1fr;
            gap: 0.75rem;
        }
        @media(min-width: 640px) { .question-actions { grid-template-columns: repeat(3, 1fr); } }

        .quiz-sidebar {
            width: var(--sidebar-width);
            background-color: #f7fafc;
            border-left: 1px solid #e2e8f0;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease-in-out, width 0.3s ease-in-out, padding 0.3s ease-in-out;
            overflow-y: auto;
        }
        .quiz-sidebar.collapsed {
            transform: translateX(100%);
            width: 0;
            padding: 0;
            border-left: none;
            overflow: hidden;
        }
        .sidebar-toggle {
            position: absolute;
            top: 50%;
            right: var(--sidebar-width);
            transform: translateY(-50%);
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 0.5rem 0 0 0.5rem;
            padding: 0.75rem 0.25rem;
            cursor: pointer;
            z-index: 5;
            transition: right 0.3s ease-in-out;
        }
        .quiz-sidebar.collapsed + .sidebar-toggle { right: 0; }
        .sidebar-toggle svg { width: 1.25rem; height: 1.25rem; }

        .palette-header {
            text-align: center;
            font-weight: 600;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid #e2e8f0;
        }
        .question-palette {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(40px, 1fr));
            gap: 0.5rem;
            margin-bottom: 1rem;
        }
        .palette-item {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 0.25rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            border: 1px solid transparent;
        }
        .palette-item.current {
            border-color: var(--primary-dark);
            transform: scale(1.1);
            box-shadow: var(--shadow-md);
        }
        .palette-item.correct { background-color: var(--bg-answered); border: 1px solid var(--border-answered); color: var(--color-answered); }
        .palette-item.incorrect { background-color: var(--bg-incorrect); border: 1px solid var(--border-incorrect); color: var(--color-incorrect); }
        .palette-item.unattempted { background-color: #f7fafc; border: 1px solid #e2e8f0; color: #4a5568; }


        /* Palette Status Colors */
        .status-notVisited { background-color: var(--bg-not-visited); border-color: var(--border-not-visited); color: #4a5568; }
        .status-notAnswered { background-color: var(--bg-not-answered); border-color: var(--border-not-answered); color: var(--color-not-answered); }
        .status-answered { background-color: var(--bg-answered); border-color: var(--border-answered); color: var(--color-answered); }
        .status-markedForReview { background-color: var(--bg-marked); border-color: var(--border-marked); color: var(--color-marked); position: relative; }
        .status-answeredAndMarked { background-color: var(--bg-answered-marked); border-color: var(--border-answered-marked); color: var(--color-answered-marked); position: relative; }

        .status-markedForReview::after, .status-answeredAndMarked::after {
            content: '';
            position: absolute;
            bottom: 4px;
            right: 4px;
            width: 8px;
            height: 8px;
            background-color: var(--color-marked);
            border-radius: 50%;
        }
        
        /* --- Results Screen --- */
        .results-card { max-width: 1000px; background-color: #f7fafc; }
        .results-content { padding: 2.5rem; }
        .results-header { text-align: center; margin-bottom: 2rem; }
        .results-header h1 { font-size: 2.5rem; font-weight: 700; color: #1a202c; }
        .feedback-card {
            padding: 1.5rem;
            border-radius: 0.75rem;
            margin: 1.5rem 0;
            text-align: center;
            border: 2px solid;
        }
        .feedback-card h2 { margin: 0 0 0.5rem 0; font-size: 1.75rem; }
        .feedback-card .score { font-size: 4rem; font-weight: 800; line-height: 1; }
        .feedback-card .percentage { font-size: 1.5rem; font-weight: 600; }
        
        .results-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 1.5rem;
            margin: 2rem 0;
        }
        @media(min-width: 768px) { .results-grid { grid-template-columns: repeat(2, 1fr); } }

        .summary-card {
            background-color: white;
            padding: 1.5rem;
            border-radius: 0.75rem;
            box-shadow: var(--shadow-lg);
        }
        .summary-card h3 { margin-top: 0; font-size: 1.25rem; color: #2d3748; }
        .summary-list { list-style: none; padding: 0; }
        .summary-list li { display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid #edf2f7; }
        .summary-list li:last-child { border-bottom: none; }
        .css-bar { background-color: #e2e8f0; border-radius: 99px; height: 12px; overflow: hidden; }
        .css-bar-fill { height: 100%; border-radius: 99px; transition: width 0.8s ease-out; }
        .results-actions {
            display: flex;
            justify-content: center;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .social-card {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            text-align: center;
        }
        .social-card .btn { background-color: rgba(255,255,255,0.2); color: white; border: 1px solid white; }
        .social-card .btn:hover { background-color: rgba(255,255,255,0.3); }

        /* --- Review Screen --- */
        .review-card { max-width: 1400px; display: flex; flex-direction: column; height: calc(100vh - 2rem); }
        .review-top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 1.5rem;
            background-color: #fff;
            border-bottom: 1px solid #e2e8f0;
            flex-shrink: 0;
        }
        .review-main-area { display: flex; flex: 1; overflow: hidden; }
        .review-question-pane { flex: 1; padding: 1.5rem; overflow-y: auto; }
        .review-sidebar { width: var(--sidebar-width); background: #f7fafc; border-left: 1px solid #e2e8f0; display: flex; flex-direction: column; overflow-y: auto; }
        
        .review-q-header { padding: 1rem; background-color: #edf2f7; border-radius: 0.5rem; margin-bottom: 1rem; display: flex; justify-content: space-between; align-items: center; }
        .review-q-status { display: flex; align-items: center; font-weight: 600; }
        .review-q-text { font-size: 1.125rem; font-weight: 600; margin-bottom: 1.5rem; }
        
        .review-option {
            border-width: 2px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.75rem 1rem;
        }
        .review-option.user-selected {
            box-shadow: var(--shadow-md);
        }
        .review-option.correct {
            border-color: var(--color-correct);
            background-color: var(--bg-correct);
            color: var(--color-answered);
        }
        .review-option.incorrect {
            border-color: var(--color-incorrect);
            background-color: var(--bg-incorrect);
            color: var(--color-not-answered);
        }
        .review-option.not-selected {
             background-color: #f7fafc;
             border-color: #e2e8f0;
        }
        .review-explanation {
            margin-top: 1.5rem;
            padding: 1.5rem;
            background-color: #f0f9ff;
            border-left: 4px solid #3b82f6;
            border-radius: 0.25rem;
            animation: fadeIn 0.5s ease-in-out;
        }
        .review-explanation h4 { margin-top: 0; display: flex; align-items: center; gap: 0.5rem; font-size: 1.1rem; color: #1e3a8a; }
        .review-actions {
            padding: 1.5rem 0 0 0;
            border-top: 1px solid #e2e8f0;
            margin-top: 1.5rem;
            display: flex;
            justify-content: space-between;
        }
        .review-sidebar-card { background: white; border-radius: 0.5rem; padding: 1rem; margin: 1rem; box-shadow: var(--shadow-sm); }
        .review-sidebar-card h4 { margin-top: 0; font-size: 1rem; text-align: center; }
        
        .toggle-switch {
            display: inline-flex;
            align-items: center;
            cursor: pointer;
        }
        .toggle-switch input { display: none; }
        .toggle-switch .slider {
            width: 44px; height: 24px;
            background-color: #a0aec0;
            border-radius: 9999px;
            position: relative;
            transition: background-color 0.2s;
        }
        .toggle-switch .slider::before {
            content: '';
            position: absolute;
            width: 16px; height: 16px;
            border-radius: 50%;
            background-color: white;
            top: 4px; left: 4px;
            transition: transform 0.2s;
        }
        .toggle-switch input:checked + .slider { background-color: var(--color-correct); }
        .toggle-switch input:checked + .slider::before { transform: translateX(20px); }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Utility */
        .font-bold { font-weight: 700; }
        .font-semibold { font-weight: 600; }
        .text-center { text-align: center; }
        .text-sm { font-size: 0.875rem; }
        .mb-4 { margin-bottom: 1rem; }
        .mt-auto { margin-top: auto; }
        .svg-icon {
            display: inline-block;
            width: 1em;
            height: 1em;
            stroke-width: 0;
            stroke: currentColor;
            fill: currentColor;
            vertical-align: middle;
        }

      </style>
    </head>
    <body>
      
      <!-- SVG Icons Definition -->
      <svg class="hidden" style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <defs>
          <symbol id="icon-play" viewBox="0 0 24 24" fill="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.348a1.125 1.125 0 010 1.971l-11.54 6.347a1.125 1.125 0 01-1.667-.985V5.653z" /></symbol>
          <symbol id="icon-pause" viewBox="0 0 24 24" fill="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15.75 5.25v13.5m-7.5-13.5v13.5" /></symbol>
          <symbol id="icon-fullscreen-enter" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75v4.5m0-4.5h-4.5m4.5 0L15 9m5.25 11.25v-4.5m0 4.5h-4.5m4.5 0L15 15" /></symbol>
          <symbol id="icon-fullscreen-exit" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 9V4.5M9 9H4.5M9 9L3.75 3.75M9 15v4.5M9 15H4.5M9 15l-5.25 5.25M15 9V4.5M15 9h4.5M15 9l5.25-5.25M15 15v4.5M15 15h4.5M15 15l5.25 5.25" /></symbol>
          <symbol id="icon-chevron-left" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15.75 19.5L8.25 12l7.5-7.5" /></symbol>
          <symbol id="icon-chevron-right" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8.25 4.5l7.5 7.5-7.5 7.5" /></symbol>
          <symbol id="icon-check-circle" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></symbol>
          <symbol id="icon-x-circle" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></symbol>
          <symbol id="icon-minus-circle" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></symbol>
          <symbol id="icon-clock" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" /></symbol>
          <symbol id="icon-lightbulb" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.311V21m0 0H9m3-3.75V6.75m0-3a3 3 0 00-3 3h6a3 3 0 00-3-3z" /></symbol>
          <symbol id="icon-youtube" viewBox="0 0 24 24"><path d="M10,15L15.19,12L10,9V15M21.56,7.17C21.69,7.64 21.78,8.27 21.84,9.07C21.91,9.87 21.94,10.56 21.94,11.16L22,12C22,14.19 21.84,15.8 21.56,16.83C21.31,17.73 20.73,18.31 19.83,18.56C19.36,18.69 18.73,18.78 17.93,18.84C17.13,18.91 16.44,18.94 15.84,18.94L15,19C12.81,19 11.2,18.84 10.17,18.56C9.27,18.31 8.69,17.73 8.44,16.83C8.31,16.36 8.22,15.73 8.16,14.93C8.09,14.13 8.06,13.44 8.06,12.84L8,12C8,9.81 8.16,8.2 8.44,7.17C8.69,6.27 9.27,5.69 10.17,5.44C10.64,5.31 11.27,5.22 12.07,5.16C12.87,5.09 13.56,5.06 14.16,5.06L15,5C17.19,5 18.8,5.16 19.83,5.44C20.73,5.69 21.31,6.27 21.56,7.17Z"></path></symbol>
          <symbol id="icon-telegram" viewBox="0 0 24 24"><path d="M9.78,18.65L10.26,14.21L18.73,7.45M9.78,18.65L12.73,17.54L14.21,15.07L12.06,17.03M9.78,18.65L6.29,17.3L3.09,16.1L3.18,16.27C3.43,16.77 3.63,17.26 3.76,17.74C3.92,18.31 3.96,18.83 3.96,19.31C3.96,19.31 4,19.31 4,19.32L4,19.33C4,19.73 4.07,20.13 4.22,20.5C4.39,20.88 4.62,21.23 4.93,21.53C5.23,21.83 5.59,22.07 5.97,22.24C6.34,22.41 6.73,22.5 7.12,22.5C7.5,22.5 7.85,22.42 8.17,22.27C8.48,22.11 8.77,21.89 9.03,21.63C9.29,21.37 9.5,21.07 9.66,20.75C9.83,20.42 9.91,20.05 9.91,19.65L9.78,18.65M18.73,7.45L7.05,12.92L3,11.62L20.94,4.69L18.73,7.45Z"></path></symbol>
        </defs>
      </svg>
    
      <div class="app-container">
        
        <div id="instructionsScreen" class="card instructions-card"></div>
        <div id="quizScreen" class="card quiz-container hidden"></div>
        <div id="resultsScreen" class="card results-card hidden"></div>
        <div id="reviewScreen" class="card review-card hidden"></div>

      </div>

      <script id="quiz-data" type="application/json">${JSON.stringify({
          quizTitle,
          questions,
          totalTime: totalTimeInSeconds,
          negativeMarking,
          appName,
          youtubeLink,
          telegramLink,
          instructionStrings: finalInstructionStrings,
          language,
      })}</script>

      <script>
        document.addEventListener('DOMContentLoaded', () => {
            const S = { // State
                appPhase: 'instructions',
                questions: [],
                userAnswers: [],
                currentQuestionIndex: 0,
                timeLeft: 0,
                timerInterval: null,
                isTimerPaused: false,
                autoNext: true,
                isFullScreen: false,
                isSidebarCollapsed: true,
                quizResults: null,
                reviewIndex: 0
            };

            const C = JSON.parse(document.getElementById('quiz-data').textContent);
            C.QuestionStatus = { NotVisited: 'notVisited', NotAnswered: 'notAnswered', Answered: 'answered', MarkedForReview: 'markedForReview', AnsweredAndMarked: 'answeredAndMarked' };
            
            const root = document.querySelector('.app-container');

            // --- TEMPLATE RENDERERS ---
            const render = (template, target) => { target.innerHTML = template; };

            const instructionsTemplate = () => {
                const i = C.instructionStrings;
                return \`
                <div class="instructions-content">
                    <h1>\${i.screenTitle}</h1>
                    <div class="instructions-summary">
                        <p><strong>\${i.quizNamePrefix}</strong> \${C.quizTitle}</p>
                        <p>\${i.totalTime}</p>
                        <p>\${i.totalMarks}</p>
                    </div>
                    <h2 class="font-bold mb-4">Please read the following instructions carefully:</h2>
                    <ul class="instructions-list">
                        <li>\${i.instruction1}</li><li>\${i.instruction2}</li><li>\${i.instruction3}</li>
                        <li>\${i.instruction4}</li><li>\${i.instruction5}</li><li>\${i.instruction6}</li>
                        <li>\${i.instruction7}</li>
                    </ul>
                    <div class="instructions-summary">
                        <p class="font-bold">\${i.defaultLangMessage}</p>
                        <p class="text-sm">\${i.defaultLangDisclaimer}</p>
                    </div>
                    <label class="mb-4" style="display: flex; align-items: start; gap: 0.5rem; cursor: pointer;">
                        <input type="checkbox" id="agreeCheckbox" style="margin-top: 4px;">
                        <span>\${i.agreeCheckboxLabel}</span>
                    </label>
                    <div class="instructions-actions">
                        <button id="backButton" class="btn btn-secondary">\${i.backButton}</button>
                        <button id="proceedButton" class="btn btn-primary" disabled>\${i.proceedButton}</button>
                    </div>
                </div>\`;
            };

            const quizTemplate = () => \`
                <div class="quiz-top-bar">
                    <h1>\${C.appName} - \${C.quizTitle}</h1>
                    <div class="top-bar-controls">
                        <div class="timer-display">
                            <svg class="svg-icon" style="width:1.25rem;height:1.25rem;"><use href="#icon-clock"></use></svg>
                            <span id="timer">00:00</span>
                            <button id="pauseTimerBtn" class="control-btn" title="Pause Timer">
                                <svg class="svg-icon" id="pauseIcon"><use href="#icon-pause"></use></svg>
                                <svg class="svg-icon hidden" id="playIcon"><use href="#icon-play"></use></svg>
                            </button>
                        </div>
                        <label class="toggle-switch" title="Toggle Auto-Next">
                            <input type="checkbox" id="autoNextToggle" \${S.autoNext ? 'checked' : ''}>
                            <span class="slider"></span>
                        </label>
                        <button id="fullscreenBtn" class="control-btn" title="Toggle Fullscreen">
                            <svg class="svg-icon" id="fullscreenEnterIcon"><use href="#icon-fullscreen-enter"></use></svg>
                            <svg class="svg-icon hidden" id="fullscreenExitIcon"><use href="#icon-fullscreen-exit"></use></svg>
                        </button>
                    </div>
                </div>
                <div class="quiz-main-area">
                    <div class="question-pane">
                        <div class="question-header">
                            <div id="questionNumber" class="font-bold"></div>
                            <div id="questionMarks" class="text-sm"></div>
                        </div>
                        <p id="questionText" class="question-text"></p>
                        <div id="optionsContainer" class="options-grid"></div>
                        <div class="question-actions">
                            <button id="markReviewBtn" class="btn btn-secondary">Mark & Next</button>
                            <button id="clearResponseBtn" class="btn btn-secondary">Clear Response</button>
                            <button id="saveNextBtn" class="btn btn-primary"></button>
                        </div>
                    </div>
                    <div id="quizSidebar" class="quiz-sidebar collapsed">
                        <h3 class="palette-header">Question Palette</h3>
                        <div id="questionPalette" class="question-palette"></div>
                        <div class="mt-auto">
                            <button id="submitQuizBtn" class="btn btn-primary" style="width: 100%;">Submit Test</button>
                        </div>
                    </div>
                    <button id="sidebarToggle" class="sidebar-toggle" title="Toggle Sidebar">
                        <svg class="svg-icon"><use href="#icon-chevron-left"></use></svg>
                    </button>
                </div>\`;
            
            const resultsTemplate = () => {
                const r = S.quizResults;
                const feedback = getMotivationalFeedback(r.percentage);
                return \`
                <div class="results-content">
                    <div class="results-header"><h1>Quiz Results</h1></div>
                    <div class="feedback-card" style="border-color: \${feedback.color}; background-color: \${feedback.bgColor};">
                        <h2 style="color: \${feedback.color};">\${feedback.title}</h2>
                        <p>\${feedback.message}</p>
                        <div class="score" style="color: \${feedback.color};">\${r.score} / \${r.totalQuestions}</div>
                        <div class="percentage" style="color: \${feedback.color};">(\${r.percentage}%)</div>
                    </div>
                    <div class="results-grid">
                        <div class="summary-card">
                            <h3>Score Summary</h3>
                            <ul class="summary-list">
                                <li><span>Total Questions:</span> <span class="font-semibold">\${r.totalQuestions}</span></li>
                                <li style="color: var(--color-correct);"><span>Correct Answers:</span> <span class="font-semibold">\${r.correct}</span></li>
                                <li style="color: var(--color-incorrect);"><span>Incorrect Answers:</span> <span class="font-semibold">\${r.incorrect}</span></li>
                                <li style="color: var(--color-unattempted);"><span>Unattempted:</span> <span class="font-semibold">\${r.unattempted}</span></li>
                                <li style="color: var(--color-incorrect);"><span>Negative Marking:</span> <span class="font-semibold">-\${r.negativeMarksApplied.toFixed(2)}</span></li>
                            </ul>
                        </div>
                        <div class="summary-card">
                            <h3>Performance Breakdown</h3>
                            <div id="chart-container"></div>
                        </div>
                        <div class="summary-card social-card" style="grid-column: 1 / -1;">
                             <h3>Stay Connected!</h3>
                             <p>Join our channels for more quizzes and updates.</p>
                             <div style="display:flex; justify-content:center; gap:1rem; margin-top:1rem;">
                                <a href="\${C.youtubeLink}" target="_blank" class="btn"><svg class="svg-icon" style="width:1.25rem;height:1.25rem;"><use href="#icon-youtube"></use></svg> YouTube</a>
                                <a href="\${C.telegramLink}" target="_blank" class="btn"><svg class="svg-icon" style="width:1.25rem;height:1.25rem;"><use href="#icon-telegram"></use></svg> Telegram</a>
                             </div>
                        </div>
                    </div>
                    <div class="results-actions">
                        <button id="reviewAnswersBtn" class="btn btn-primary">View Solutions</button>
                        <button id="reattemptQuizBtn" class="btn btn-secondary">Re-attempt Quiz</button>
                    </div>
                </div>\`;
            };

            const reviewTemplate = () => \`
                <div class="review-top-bar">
                    <h2 class="font-bold">Review: \${C.quizTitle}</h2>
                    <button id="exitReviewBtn" class="btn btn-secondary text-sm">Back to Results</button>
                </div>
                <div class="review-main-area">
                    <div class="review-question-pane">
                         <div class="review-q-header">
                            <div id="reviewQuestionNumber" class="font-bold"></div>
                            <div id="reviewQuestionStatus" class="review-q-status"></div>
                        </div>
                        <p id="reviewQuestionText" class="review-q-text"></p>
                        <div id="reviewOptionsContainer" class="options-grid"></div>
                        <button id="toggleExplanationBtn" class="btn btn-secondary" style="margin-top: 1.5rem;">Show Solution</button>
                        <div id="reviewExplanation" class="review-explanation hidden">
                            <h4><svg class="svg-icon" style="width:1.25rem;height:1.25rem;"><use href="#icon-lightbulb"></use></svg>Explanation</h4>
                            <p id="explanationText"></p>
                        </div>
                         <div class="review-actions">
                            <button id="prevReviewBtn" class="btn btn-secondary">Previous</button>
                            <button id="nextReviewBtn" class="btn btn-secondary">Next</button>
                        </div>
                    </div>
                    <div class="review-sidebar">
                        <div class="review-sidebar-card">
                            <h4>Question Stats</h4>
                            <div id="review-sidebar-stats"></div>
                        </div>
                        <div class="review-sidebar-card" style="flex: 1; display: flex; flex-direction: column;">
                            <h4>Navigation</h4>
                            <div id="review-palette" class="question-palette" style="overflow-y: auto; flex: 1; align-content: flex-start;"></div>
                        </div>
                    </div>
                </div>
                \`;

            // --- CORE LOGIC ---
            function init() {
                S.questions = C.questions;
                S.timeLeft = C.totalTime;
                showScreen('instructions');
            }

            function showScreen(screenName) {
                document.querySelectorAll('.card').forEach(s => s.classList.add('hidden'));
                const screenEl = document.getElementById(screenName + 'Screen');
                
                if (screenName === 'instructions') render(instructionsTemplate(), screenEl);
                if (screenName === 'quiz') render(quizTemplate(), screenEl);
                if (screenName === 'results') render(resultsTemplate(), screenEl);
                if (screenName === 'review') render(reviewTemplate(), screenEl);

                screenEl.classList.remove('hidden');
                S.appPhase = screenName;
                addEventListeners(); // Re-add listeners for new DOM
                
                if (screenName === 'quiz') postQuizRender();
                if (screenName === 'results') postResultsRender();
                if (screenName === 'review') postReviewRender();
            }

            // --- SCREEN-SPECIFIC LOGIC & LISTENERS ---
            function addEventListeners() {
                if (S.appPhase === 'instructions') {
                    const agree = document.getElementById('agreeCheckbox');
                    const proceed = document.getElementById('proceedButton');
                    agree.onchange = () => { proceed.disabled = !agree.checked; };
                    proceed.onclick = startQuiz;
                    document.getElementById('backButton').onclick = () => window.close();
                } else if (S.appPhase === 'quiz') {
                    document.getElementById('pauseTimerBtn').onclick = toggleTimerPause;
                    document.getElementById('autoNextToggle').onchange = (e) => { S.autoNext = e.target.checked; };
                    document.getElementById('fullscreenBtn').onclick = toggleFullScreen;
                    document.getElementById('markReviewBtn').onclick = handleMarkForReview;
                    document.getElementById('clearResponseBtn').onclick = handleClearResponse;
                    document.getElementById('saveNextBtn').onclick = handleSaveAndNext;
                    document.getElementById('submitQuizBtn').onclick = submitQuiz;
                    document.getElementById('sidebarToggle').onclick = toggleSidebar;
                } else if (S.appPhase === 'results') {
                    document.getElementById('reviewAnswersBtn').onclick = startReview;
                    document.getElementById('reattemptQuizBtn').onclick = startQuiz;
                } else if (S.appPhase === 'review') {
                    document.getElementById('exitReviewBtn').onclick = () => showScreen('results');
                    document.getElementById('prevReviewBtn').onclick = () => navigateReview(-1);
                    document.getElementById('nextReviewBtn').onclick = () => navigateReview(1);
                    document.getElementById('toggleExplanationBtn').onclick = toggleExplanation;
                }
            }

            function startQuiz() {
                S.currentQuestionIndex = 0;
                S.timeLeft = C.totalTime;
                S.userAnswers = S.questions.map(q => ({
                    questionId: q.id, selectedOptionIndex: null, status: C.QuestionStatus.NotVisited, isMarked: false,
                }));
                S.userAnswers[0].status = C.QuestionStatus.NotAnswered;
                showScreen('quiz');
                // Try to enter fullscreen
                document.documentElement.requestFullscreen().catch(err => {
                    console.warn(\`Could not automatically enter fullscreen: \${err.message}\`);
                });
            }

            function postQuizRender() {
                updateTimerDisplay();
                renderQuestion();
                renderPalette();
                if (!S.timerInterval) startTimer();
            }

            function renderQuestion() {
                const q = S.questions[S.currentQuestionIndex];
                if (!q) return;
                document.getElementById('questionNumber').textContent = \`Question \${S.currentQuestionIndex + 1} of \${S.questions.length}\`;
                document.getElementById('questionMarks').textContent = \`Marks: +1.00 / -\${C.negativeMarking.toFixed(2)}\`;
                document.getElementById('questionText').textContent = q.text;
                const opts = document.getElementById('optionsContainer');
                opts.innerHTML = '';
                const answer = S.userAnswers[S.currentQuestionIndex];
                q.options.forEach((opt, i) => {
                    const btn = document.createElement('button');
                    btn.className = 'option-btn';
                    if (answer.selectedOptionIndex === i) btn.classList.add('selected');
                    btn.innerHTML = \`<span class="option-prefix">\${String.fromCharCode(65 + i)}.</span><span>\${opt}</span>\`;
                    btn.onclick = () => selectOption(i);
                    opts.appendChild(btn);
                });
                document.getElementById('saveNextBtn').textContent = (S.currentQuestionIndex === S.questions.length - 1) ? 'Save & Finish' : 'Save & Next';
            }

            function renderPalette() {
                const p = document.getElementById('questionPalette');
                p.innerHTML = '';
                S.userAnswers.forEach((ans, i) => {
                    const item = document.createElement('div');
                    item.className = \`palette-item status-\${ans.status}\`;
                    if (i === S.currentQuestionIndex) item.classList.add('current');
                    item.textContent = i + 1;
                    item.onclick = () => navigateToQuestion(i);
                    p.appendChild(item);
                });
            }
            
            function selectOption(index) {
                const answer = S.userAnswers[S.currentQuestionIndex];
                answer.selectedOptionIndex = index;
                answer.status = answer.isMarked ? C.QuestionStatus.AnsweredAndMarked : C.QuestionStatus.Answered;
                renderQuestion(); renderPalette();
                if (S.autoNext && S.currentQuestionIndex < S.questions.length - 1) {
                    setTimeout(() => navigateToQuestion(S.currentQuestionIndex + 1), 300);
                }
            }

            function navigateToQuestion(index) {
                if (index === S.currentQuestionIndex) return;
                S.currentQuestionIndex = index;
                const answer = S.userAnswers[index];
                if (answer.status === C.QuestionStatus.NotVisited) answer.status = C.QuestionStatus.NotAnswered;
                renderQuestion(); renderPalette();
            }
            
            function handleSaveAndNext() {
                if (S.currentQuestionIndex < S.questions.length - 1) navigateToQuestion(S.currentQuestionIndex + 1);
                else submitQuiz();
            }
            
            function handleMarkForReview() {
                const answer = S.userAnswers[S.currentQuestionIndex];
                answer.isMarked = !answer.isMarked;
                answer.status = answer.selectedOptionIndex !== null ? (answer.isMarked ? C.QuestionStatus.AnsweredAndMarked : C.QuestionStatus.Answered) : (answer.isMarked ? C.QuestionStatus.MarkedForReview : C.QuestionStatus.NotAnswered);
                handleSaveAndNext();
            }
            
            function handleClearResponse() {
                const answer = S.userAnswers[S.currentQuestionIndex];
                answer.selectedOptionIndex = null;
                answer.status = answer.isMarked ? C.QuestionStatus.MarkedForReview : C.QuestionStatus.NotAnswered;
                renderQuestion(); renderPalette();
            }

            function submitQuiz() {
                if (confirm('Are you sure you want to submit the test?')) {
                    stopTimer();
                    calculateResults();
                    showScreen('results');
                }
            }

            // --- TIMER ---
            function startTimer() { stopTimer(); S.timerInterval = setInterval(tick, 1000); }
            function stopTimer() { clearInterval(S.timerInterval); S.timerInterval = null; }
            function tick() {
                if (S.isTimerPaused) return;
                S.timeLeft--;
                updateTimerDisplay();
                if (S.timeLeft <= 0) { alert('Time is up!'); submitQuiz(); }
            }
            function updateTimerDisplay() {
                const mins = Math.floor(S.timeLeft / 60).toString().padStart(2, '0');
                const secs = (S.timeLeft % 60).toString().padStart(2, '0');
                const timerEl = document.getElementById('timer');
                if (timerEl) timerEl.textContent = \`\${mins}:\${secs}\`;
            }
            function toggleTimerPause() {
                S.isTimerPaused = !S.isTimerPaused;
                document.getElementById('pauseIcon').classList.toggle('hidden', S.isTimerPaused);
                document.getElementById('playIcon').classList.toggle('hidden', !S.isTimerPaused);
            }
            
            // --- RESULTS ---
            function calculateResults() {
                let correct = 0, incorrect = 0, unattempted = 0, score = 0, negativeMarksApplied = 0;
                S.userAnswers.forEach((ua, i) => {
                    const q = S.questions[i];
                    if (ua.selectedOptionIndex === null) unattempted++;
                    else if (ua.selectedOptionIndex === q.correctIndex) { correct++; score++; } 
                    else { incorrect++; score -= C.negativeMarking; negativeMarksApplied += C.negativeMarking; }
                });
                score = Math.max(0, score);
                const total = S.questions.length;
                const percentage = total > 0 ? (score / total) * 100 : 0;
                S.quizResults = { correct, incorrect, unattempted, score: score.toFixed(2), percentage: percentage.toFixed(1), totalQuestions: total, negativeMarksApplied };
            }

            function getMotivationalFeedback(percentage) {
                if (percentage >= 85) return { title: "Outstanding!", message: "Future Officer, you have a strong grasp of the material.", color: 'var(--color-correct)', bgColor: 'var(--bg-correct)' };
                if (percentage >= 70) return { title: "Great Job!", message: "You're on the right track. Review your mistakes!", color: '#4361ee', bgColor: '#e0e7ff' };
                if (percentage >= 50) return { title: "Solid Effort!", message: "There's room for improvement. Keep practicing!", color: 'var(--color-unattempted)', bgColor: 'var(--bg-unattempted)' };
                return { title: "Keep Going!", message: "Don't be discouraged! This is a learning opportunity.", color: 'var(--color-incorrect)', bgColor: 'var(--bg-incorrect)' };
            }

            function postResultsRender() {
                const chartContainer = document.getElementById('chart-container');
                chartContainer.innerHTML = '';
                const data = [
                    { label: 'Correct', value: S.quizResults.correct, color: 'var(--color-correct)' },
                    { label: 'Incorrect', value: S.quizResults.incorrect, color: 'var(--color-incorrect)' },
                    { label: 'Unattempted', value: S.quizResults.unattempted, color: 'var(--color-unattempted)' }
                ];
                data.forEach(item => {
                    const barWrapper = document.createElement('div');
                    barWrapper.style.marginBottom = '1rem';
                    const percent = (item.value / S.quizResults.totalQuestions) * 100;
                    barWrapper.innerHTML = \`
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.25rem;">
                            <span class="font-semibold text-sm" style="color: \${item.color};">\${item.label}</span>
                            <span class="text-sm font-medium">\${item.value} / \${S.quizResults.totalQuestions}</span>
                        </div>
                        <div class="css-bar">
                            <div class="css-bar-fill" style="width: 0%; background: \${item.color};" data-percent="\${percent}"></div>
                        </div>
                    \`;
                    chartContainer.appendChild(barWrapper);
                });
                // Animate bars
                setTimeout(() => {
                    document.querySelectorAll('.css-bar-fill').forEach(bar => {
                        bar.style.width = bar.getAttribute('data-percent') + '%';
                    });
                }, 100);
            }

            // --- REVIEW ---
            function startReview() { S.reviewIndex = 0; showScreen('review'); }
            
            function postReviewRender() {
                renderReviewQuestion();
                renderReviewPalette();
            }

            function renderReviewQuestion() {
                const q = S.questions[S.reviewIndex];
                const ua = S.userAnswers[S.reviewIndex];
                
                const statusInfo = ua.selectedOptionIndex === null ? { text: 'Unattempted', color: 'var(--color-unattempted)', icon: 'minus-circle' }
                                 : ua.selectedOptionIndex === q.correctIndex ? { text: 'Correct', color: 'var(--color-correct)', icon: 'check-circle' }
                                 : { text: 'Incorrect', color: 'var(--color-incorrect)', icon: 'x-circle' };

                document.getElementById('reviewQuestionNumber').textContent = \`Question \${S.reviewIndex + 1} of \${S.questions.length}\`;
                const statusEl = document.getElementById('reviewQuestionStatus');
                statusEl.innerHTML = \`<svg class="svg-icon" style="width:1.25rem;height:1.25rem; margin-right: 0.5rem;"><use href="#icon-\${statusInfo.icon}"></use></svg> \${statusInfo.text}\`;
                statusEl.style.color = statusInfo.color;

                document.getElementById('reviewQuestionText').textContent = q.text;
                const opts = document.getElementById('reviewOptionsContainer');
                opts.innerHTML = '';
                q.options.forEach((opt, i) => {
                    const div = document.createElement('div');
                    div.className = 'option-btn review-option';
                    
                    const isCorrect = i === q.correctIndex;
                    const isUserSelected = i === ua.selectedOptionIndex;

                    if (isCorrect) {
                        div.classList.add('correct');
                    } else if (isUserSelected) {
                        div.classList.add('incorrect');
                    } else {
                        div.classList.add('not-selected');
                    }
                    if(isUserSelected) div.classList.add('user-selected');

                    let iconHtml = '';
                    if (isCorrect) iconHtml = \`<svg class="svg-icon" style="width:1.5rem;height:1.5rem;color:var(--color-correct);"><use href="#icon-check-circle"></use></svg>\`;
                    if (isUserSelected && !isCorrect) iconHtml = \`<svg class="svg-icon" style="width:1.5rem;height:1.5rem;color:var(--color-incorrect);"><use href="#icon-x-circle"></use></svg>\`;

                    div.innerHTML = \`<div><span class="option-prefix">\${String.fromCharCode(65 + i)}.</span><span>\${opt}</span></div> \${iconHtml}\`;
                    opts.appendChild(div);
                });
                document.getElementById('explanationText').textContent = q.explanation;
                document.getElementById('prevReviewBtn').disabled = S.reviewIndex === 0;
                document.getElementById('nextReviewBtn').disabled = S.reviewIndex === S.questions.length - 1;

                // Update sidebar stats
                document.getElementById('review-sidebar-stats').innerHTML = \`
                    <ul class="summary-list text-sm">
                        <li><span>Status:</span> <span class="font-semibold" style="color: \${statusInfo.color};">\${statusInfo.text}</span></li>
                    </ul>
                \`;
            }

            function renderReviewPalette() {
                const palette = document.getElementById('review-palette');
                palette.innerHTML = '';
                S.questions.forEach((q, i) => {
                    const ua = S.userAnswers[i];
                    const item = document.createElement('div');
                    item.className = 'palette-item';
                    
                    if (ua.selectedOptionIndex === null) item.classList.add('unattempted');
                    else if (ua.selectedOptionIndex === q.correctIndex) item.classList.add('correct');
                    else item.classList.add('incorrect');
                    
                    if (i === S.reviewIndex) item.classList.add('current');
                    
                    item.textContent = i + 1;
                    item.onclick = () => {
                         S.reviewIndex = i;
                         renderReviewQuestion();
                         renderReviewPalette(); // To update the 'current' item
                         document.getElementById('reviewExplanation').classList.add('hidden');
                         document.getElementById('toggleExplanationBtn').textContent = 'Show Solution';
                    };
                    palette.appendChild(item);
                });
            }


            function navigateReview(dir) {
                const newIndex = S.reviewIndex + dir;
                if (newIndex >= 0 && newIndex < S.questions.length) {
                    S.reviewIndex = newIndex;
                    renderReviewQuestion();
                    renderReviewPalette();
                    document.getElementById('reviewExplanation').classList.add('hidden');
                    document.getElementById('toggleExplanationBtn').textContent = 'Show Solution';
                }
            }
            function toggleExplanation() {
                const exp = document.getElementById('reviewExplanation');
                const btn = document.getElementById('toggleExplanationBtn');
                const isHidden = exp.classList.toggle('hidden');
                btn.textContent = isHidden ? 'Show Solution' : 'Hide Solution';
            }

            // --- HELPERS ---
            function toggleFullScreen() {
                if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(err => console.error(err));
                else if (document.exitFullscreen) document.exitFullscreen();
            }
            document.addEventListener('fullscreenchange', () => {
                S.isFullScreen = !!document.fullscreenElement;
                document.querySelector('.quiz-container').classList.toggle('fullscreen', S.isFullScreen);
                document.getElementById('fullscreenEnterIcon').classList.toggle('hidden', S.isFullScreen);
                document.getElementById('fullscreenExitIcon').classList.toggle('hidden', !S.isFullScreen);
            });
            function toggleSidebar() {
                S.isSidebarCollapsed = !S.isSidebarCollapsed;
                const sb = document.getElementById('quizSidebar');
                const sbt = document.getElementById('sidebarToggle');
                sb.classList.toggle('collapsed', S.isSidebarCollapsed);
                sbt.innerHTML = S.isSidebarCollapsed ? \`<svg class="svg-icon"><use href="#icon-chevron-left"></use></svg>\` : \`<svg class="svg-icon"><use href="#icon-chevron-right"></use></svg>\`;
            }

            init();
        });
      </script>
    </body>
    </html>
  `;
};
