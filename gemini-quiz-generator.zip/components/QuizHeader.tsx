
import React from 'react';

interface QuizHeaderProps {
  title: string;
  subtitle: string;
  timeLeft: number;
  totalTime: number;
  isSubmitted: boolean;
}

const ClockIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const QuizHeader: React.FC<QuizHeaderProps> = ({ title, subtitle, timeLeft, totalTime, isSubmitted }) => {
  const minutes = Math.floor(timeLeft / 60).toString().padStart(2, '0');
  const seconds = (timeLeft % 60).toString().padStart(2, '0');
  const progressPercentage = totalTime > 0 ? (timeLeft / totalTime) * 100 : 0;

  let progressBarClass = 'bg-primary';
  if (!isSubmitted) {
    if (timeLeft < totalTime * 0.25) {
      progressBarClass = 'bg-red-500';
    } else if (timeLeft < totalTime * 0.5) {
      progressBarClass = 'bg-yellow-500';
    }
  }
  
  const timerColor = !isSubmitted && timeLeft < 60 ? 'text-red-500' : 'text-primary';

  return (
    <div className="sticky top-0 z-10 bg-white p-5 shadow-sm border-b border-gray-200">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">{title}</h2>
        {!isSubmitted && (
          <div className={`text-2xl font-semibold ${timerColor} flex items-center`}>
            <ClockIcon className="w-6 h-6 mr-2" />
            <span>{minutes}</span>:<span>{seconds}</span>
          </div>
        )}
      </div>
      <div className="mt-1">
        <h5 className="text-sm text-gray-600">{subtitle}</h5>
      </div>
      {!isSubmitted && (
        <div className="progress-container mt-3 bg-gray-200 rounded-full h-2.5 overflow-hidden">
          <div
            className={`h-2.5 rounded-full ${progressBarClass} transition-all duration-500 ease-linear`}
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
      )}
    </div>
  );
};

export default QuizHeader;
    