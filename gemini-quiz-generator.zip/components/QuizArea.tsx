

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Question, UserAnswer, QuestionStatus } from '../types';
import QuestionContent from './QuestionContent';
import QuizTopBar from './QuizTopBar';
import QuizSidebar from './QuizSidebar';
import { SOUND_FILES, NEGATIVE_MARKING_PER_QUESTION, DEFAULT_QUIZ_SECTION_NAME } from '../constants';

// Icons for action buttons
const BookmarkAltIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 mr-2 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.25 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0111.186 0z" />
  </svg>
);
const TrashIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 mr-2 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12.56 0c1.153 0 2.243.096 3.222.261m3.222.261L5.84 18.735M9.251 5.791A48.464 48.464 0 0012 5.25c.78 0 1.536.033 2.25.098m-2.25-.098l-.584.027c-.513.023-.994.053-1.447.092M5.25 5.25H3.75m16.5 0H20.25" />
  </svg>
);
const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 mr-2 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

// Icons for new sidebar toggle
const ChevronLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
  </svg>
);
const ChevronRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
  </svg>
);


interface QuizAreaProps {
  questions: Question[];
  totalTime: number;
  onSubmit: (answers: UserAnswer[]) => void;
  initialUserAnswers: UserAnswer[]; 
  playSound: (soundId: string) => void;
  quizTopic: string; // Original topic for section display
  displayTitle: string; // Title for the top bar (App Name - Quiz Topic)
}

const QuizArea: React.FC<QuizAreaProps> = ({
  questions,
  totalTime,
  onSubmit,
  initialUserAnswers,
  playSound,
  quizTopic,
  displayTitle,
}) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<UserAnswer[]>(initialUserAnswers);
  const [timeLeft, setTimeLeft] = useState(totalTime);
  const [autoNextEnabled, setAutoNextEnabled] = useState(true);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [isSidebarVisible, setIsSidebarVisible] = useState(false);
  const [isTimerPaused, setIsTimerPaused] = useState(false);
  
  const questionStartTimeRef = useRef<number>(Date.now());
  const timerIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [currentQuestionTimeSpent, setCurrentQuestionTimeSpent] = useState(0);
  const pauseStartTimeRef = useRef<number | null>(null);

  useEffect(() => {
    // Attempt to enter fullscreen automatically when quiz starts
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
            console.warn(`Could not automatically enter fullscreen: ${err.message}`);
        });
    }
  }, []); // Run only once when component mounts


  const recordTimeSpentAndUpdate = useCallback((persistOnly: boolean = false) => {
    const endTime = isTimerPaused && pauseStartTimeRef.current ? pauseStartTimeRef.current : Date.now();
    const timeSpentSeconds = (endTime - questionStartTimeRef.current) / 1000;
    const currentQId = questions[currentQuestionIndex].id;
    
    setUserAnswers(prevAnswers => {
        const newAnswers = [...prevAnswers];
        const answerIndex = newAnswers.findIndex(a => a.questionId === currentQId);
        if (answerIndex !== -1) {
            newAnswers[answerIndex].timeTakenSeconds += timeSpentSeconds;
        }
        return newAnswers;
    });
    
    if (!persistOnly) { 
        questionStartTimeRef.current = Date.now();
        setCurrentQuestionTimeSpent(0); 
    }
  }, [currentQuestionIndex, questions, isTimerPaused]);

  const handleSubmitQuizFinal = useCallback(() => {
    if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    recordTimeSpentAndUpdate(true); 
    onSubmit(userAnswers);
  }, [recordTimeSpentAndUpdate, onSubmit, userAnswers]);

  useEffect(() => {
    questionStartTimeRef.current = Date.now(); 
    setCurrentQuestionTimeSpent(0);

    timerIntervalRef.current = setInterval(() => {
      if (isTimerPaused) return;

      setTimeLeft(prevTime => {
        if (prevTime <= 1) {
          if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
          handleSubmitQuizFinal();
          return 0;
        }
        return prevTime - 1;
      });
      setCurrentQuestionTimeSpent(prev => prev + 1);
    }, 1000);
    
    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isTimerPaused]); 

  const updateUserAnswerStatus = (qIndex: number, updates: Partial<UserAnswer>) => {
    setUserAnswers(prev => {
      const newAnswers = [...prev];
      const answerIdx = newAnswers.findIndex(a => a.questionId === questions[qIndex].id);
      if (answerIdx !== -1) {
        newAnswers[answerIdx] = { ...newAnswers[answerIdx], ...updates };
      }
      return newAnswers;
    });
  };

  const navigateToQuestion = useCallback((index: number) => {
    if (index >= 0 && index < questions.length && index !== currentQuestionIndex) {
      recordTimeSpentAndUpdate(); 
      setCurrentQuestionIndex(index);
      const targetAnswer = userAnswers.find(ua => ua.questionId === questions[index].id);
      if (targetAnswer && targetAnswer.status === QuestionStatus.NotVisited) {
        updateUserAnswerStatus(index, { status: QuestionStatus.NotAnswered });
      }
      questionStartTimeRef.current = Date.now(); 
      setCurrentQuestionTimeSpent(0);
    }
  }, [questions, currentQuestionIndex, userAnswers, recordTimeSpentAndUpdate]);


  const handleSelectOption = useCallback((optionIndex: number) => {
    if (isTimerPaused) return; 
    playSound(SOUND_FILES.CLICK);
    const currentQId = questions[currentQuestionIndex].id;
    const currentAnswer = userAnswers.find(ua => ua.questionId === currentQId);
    const currentStatus = currentAnswer?.isMarked ? QuestionStatus.AnsweredAndMarked : QuestionStatus.Answered;
    updateUserAnswerStatus(currentQuestionIndex, { selectedOptionIndex: optionIndex, status: currentStatus });

    if (autoNextEnabled && currentQuestionIndex < questions.length - 1) {
      setTimeout(() => {
        navigateToQuestion(currentQuestionIndex + 1);
      }, 300); 
    }
  }, [playSound, userAnswers, currentQuestionIndex, autoNextEnabled, questions, navigateToQuestion, isTimerPaused]);

  const handleSaveAndNext = useCallback(() => {
    if (isTimerPaused) return; 
    if (currentQuestionIndex < questions.length - 1) {
      navigateToQuestion(currentQuestionIndex + 1);
    } else {
      handleSubmitQuizFinal();
    }
  }, [currentQuestionIndex, questions.length, navigateToQuestion, handleSubmitQuizFinal, isTimerPaused]);
  
  const handleMarkForReview = useCallback(() => {
    if (isTimerPaused) return; 
    const currentQId = questions[currentQuestionIndex].id;
    const currentAnswer = userAnswers.find(ua => ua.questionId === currentQId);
    if (!currentAnswer) return;

    const newMarkedState = !currentAnswer.isMarked;
    let newStatus = currentAnswer.status;
    if (newMarkedState) {
      newStatus = currentAnswer.selectedOptionIndex !== null ? QuestionStatus.AnsweredAndMarked : QuestionStatus.MarkedForReview;
    } else {
      newStatus = currentAnswer.selectedOptionIndex !== null ? QuestionStatus.Answered : QuestionStatus.NotAnswered;
    }
    updateUserAnswerStatus(currentQuestionIndex, { isMarked: newMarkedState, status: newStatus });
    handleSaveAndNext();
  }, [userAnswers, currentQuestionIndex, questions, handleSaveAndNext, isTimerPaused]);

  const handleClearResponse = useCallback(() => {
    if (isTimerPaused) return; 
    const currentQId = questions[currentQuestionIndex].id;
    const currentAnswer = userAnswers.find(ua => ua.questionId === currentQId);
     if (!currentAnswer) return;
    const newStatus = currentAnswer.isMarked ? QuestionStatus.MarkedForReview : QuestionStatus.NotAnswered;
    updateUserAnswerStatus(currentQuestionIndex, { selectedOptionIndex: null, status: newStatus });
  }, [userAnswers, currentQuestionIndex, questions, isTimerPaused]);

  const handleToggleAutoNext = () => setAutoNextEnabled(prev => !prev);
  
  const handleFullScreenToggle = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => setIsFullScreen(true)).catch(err => {
        alert(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
      });
    } else {
      document.exitFullscreen().then(() => setIsFullScreen(false));
    }
  }, []);

  useEffect(() => {
    const fullscreenChangeHandler = () => setIsFullScreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', fullscreenChangeHandler);
    return () => document.removeEventListener('fullscreenchange', fullscreenChangeHandler);
  }, []);

  const handleToggleSidebar = () => setIsSidebarVisible(prev => !prev);

  const handleToggleTimerPause = useCallback(() => {
    setIsTimerPaused(prevPaused => {
        const newPausedState = !prevPaused;
        if (newPausedState) { 
            pauseStartTimeRef.current = Date.now();
        } else { 
            if (pauseStartTimeRef.current) {
                const pauseDuration = Date.now() - pauseStartTimeRef.current;
                questionStartTimeRef.current += pauseDuration; 
                pauseStartTimeRef.current = null;
            }
        }
        return newPausedState;
    });
  }, []);


  if (questions.length === 0) {
    return <div className="text-center p-8 text-gray-700">Loading questions or no questions available.</div>;
  }

  const currentQuestion = questions[currentQuestionIndex];
  const currentUserAnswer = userAnswers.find(ua => ua.questionId === currentQuestion.id);

  const positiveMarks = 1; 
  const negativeMarksDisplay = (NEGATIVE_MARKING_PER_QUESTION * 1).toFixed(2); 
  const sectionName = quizTopic || DEFAULT_QUIZ_SECTION_NAME;


  return (
    <div className={`flex flex-col overflow-hidden bg-white 
                    ${isFullScreen 
                        ? 'fixed top-0 left-0 w-screen h-screen z-50' 
                        : 'relative max-h-[calc(100vh-40px)] md:max-h-[calc(100vh-60px)] rounded-lg shadow-xl'
                    }`}
    >
      <QuizTopBar
        displayTitle={displayTitle}
        timeLeft={timeLeft}
        autoNextEnabled={autoNextEnabled}
        onToggleAutoNext={handleToggleAutoNext}
        onFullScreenToggle={handleFullScreenToggle}
        isFullScreen={isFullScreen}
        isTimerPaused={isTimerPaused}
        onToggleTimerPause={handleToggleTimerPause}
      />
      <div className="flex flex-1 overflow-hidden relative">
        {/* Left Pane (Question Area) */}
        <div className="flex-1 p-3 md:p-4 flex flex-col overflow-y-auto transition-all duration-300">
          <div className='mb-3 p-3 bg-gray-100 rounded-md border-b-2 border-gray-200'>
            <div className="text-sm font-semibold text-gray-700 mb-1.5">
              SECTION: <span className="font-normal text-primary">{sectionName}</span>
            </div>
            <div className="flex justify-between items-center text-xs text-gray-500">
              <span className="font-medium text-gray-600">Question No. {currentQuestionIndex + 1}</span>
              <span className="text-gray-500">Marks: <span className="text-green-600 font-medium">+{positiveMarks.toFixed(2)}</span> / <span className="text-red-600 font-medium">-{negativeMarksDisplay}</span></span>
              <span className="text-gray-500">Time on this Q: <span className="font-medium text-gray-700">{Math.floor(currentQuestionTimeSpent / 60).toString().padStart(2, '0')}:{(currentQuestionTimeSpent % 60).toString().padStart(2, '0')}</span></span>
            </div>
          </div>

          {currentUserAnswer && (
            <QuestionContent
              question={currentQuestion}
              questionNumber={currentQuestionIndex + 1}
              totalQuestions={questions.length}
              selectedOptionIndex={currentUserAnswer.selectedOptionIndex}
              onSelectOption={handleSelectOption}
              isSubmitted={false} 
            />
          )}
          
          <div className="mt-auto pt-3 grid grid-cols-1 sm:grid-cols-3 gap-2 border-t border-gray-200">
            <button
              onClick={handleMarkForReview}
              disabled={isTimerPaused}
              className="flex items-center justify-center text-sm bg-yellow-400 hover:bg-yellow-500 text-yellow-900 font-medium py-2.5 px-3 rounded-md transition duration-150 shadow-sm hover:shadow-md disabled:opacity-60 disabled:cursor-not-allowed"
            >
              <BookmarkAltIcon className="text-yellow-800"/> Mark for Review & Next
            </button>
            <button
              onClick={handleClearResponse}
              disabled={isTimerPaused}
              className="flex items-center justify-center text-sm bg-red-500 hover:bg-red-600 text-white font-medium py-2.5 px-3 rounded-md transition duration-150 shadow-sm hover:shadow-md disabled:opacity-60 disabled:cursor-not-allowed"
            >
              <TrashIcon /> Clear Response
            </button>
            <button
              onClick={handleSaveAndNext}
              disabled={(autoNextEnabled && currentQuestionIndex < questions.length -1) || isTimerPaused} 
              className="flex items-center justify-center text-sm bg-green-500 hover:bg-green-600 text-white font-medium py-2.5 px-3 rounded-md transition duration-150 shadow-sm hover:shadow-md disabled:opacity-60 disabled:cursor-not-allowed"
            >
              <CheckCircleIcon /> {currentQuestionIndex === questions.length - 1 ? "Save & Finish" : "Save & Next"}
            </button>
          </div>
        </div>

        {/* Right Pane (Sidebar) */}
        {isSidebarVisible && (
          <QuizSidebar
            userAnswers={userAnswers}
            questions={questions}
            quizTopic={quizTopic} // Use original quizTopic for section name
            currentQuestionIndex={currentQuestionIndex}
            onNavigate={navigateToQuestion}
            onSubmitQuiz={handleSubmitQuizFinal}
            isTimerPaused={isTimerPaused}
          />
        )}
         {/* Sidebar Toggle Button */}
        <button
            onClick={handleToggleSidebar}
            className={`absolute top-1/2 transform -translate-y-1/2 bg-primary text-white p-2 rounded-full shadow-lg z-30 hover:bg-primary-dark transition-all duration-300 focus:outline-none ring-2 ring-transparent focus:ring-white ${isSidebarVisible ? 'right-[320px] md:right-[288px] lg:right-[320px]' : 'right-2'}`}
            title={isSidebarVisible ? "Hide Sidebar" : "Show Sidebar"}
            aria-label={isSidebarVisible ? "Hide Sidebar" : "Show Sidebar"}
            aria-expanded={isSidebarVisible}
        >
            {isSidebarVisible ? <ChevronRightIcon className="w-5 h-5" /> : <ChevronLeftIcon className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
};

export default QuizArea;
