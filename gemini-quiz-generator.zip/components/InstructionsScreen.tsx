
import React, { useState } from 'react';
import { Language } from '../types';
import { INSTRUCTION_STRINGS, SUPPORTED_LANGUAGES } from '../constants';

// Icons
const ListBulletIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2 text-primary" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
  </svg>
);
const CheckBadgeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);


interface InstructionsScreenProps {
  quizTitle: string;
  language: Language;
  totalTimeInSeconds: number;
  numberOfQuestions: number;
  negativeMarkingPerQuestion: number;
  onProceed: () => void;
  onBack: () => void;
}

const InstructionsScreen: React.FC<InstructionsScreenProps> = ({
  quizTitle,
  language,
  totalTimeInSeconds,
  numberOfQuestions,
  negativeMarkingPerQuestion,
  onProceed,
  onBack,
}) => {
  const [agreed, setAgreed] = useState(false);
  const strings = INSTRUCTION_STRINGS[language];
  const totalTimeMinutes = Math.floor(totalTimeInSeconds / 60);
  const languageName = SUPPORTED_LANGUAGES.find(l => l.code === language)?.nativeName || language;

  return (
    <div className="max-w-3xl mx-auto my-6 p-6 md:p-8 bg-white rounded-xl shadow-custom-medium">
      <h1 className="text-2xl md:text-3xl font-bold text-center text-gray-800 mb-6">{strings.screenTitle}</h1>
      
      <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-6">
        <p className="text-sm text-gray-700"><span className="font-semibold">{strings.quizNamePrefix}</span> {quizTitle}</p>
        <p className="text-sm text-gray-700">{strings.totalTime(totalTimeMinutes)}</p>
        <p className="text-sm text-gray-700">{strings.totalMarks(numberOfQuestions)}</p> {/* Assuming 1 mark per question */}
      </div>

      <h2 className="text-lg font-semibold text-gray-700 mb-3 flex items-center">
        <ListBulletIcon />
        {strings.instructionsHeader}
      </h2>
      <ul className="list-disc list-inside space-y-2 text-sm text-gray-600 mb-6 pl-4">
        <li>{strings.instruction1(numberOfQuestions)}</li>
        <li>{strings.instruction2}</li>
        <li>{strings.instruction3(totalTimeMinutes)}</li>
        <li>{strings.instruction4(negativeMarkingPerQuestion)}</li>
        <li>{strings.instruction5}</li>
        <li>{strings.instruction6}</li>
        <li>{strings.instruction7}</li>
      </ul>

      <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200 mb-6 text-sm">
        <p className="text-yellow-800 font-medium">{strings.defaultLangMessage(languageName)}</p>
        <p className="text-yellow-700">{strings.defaultLangDisclaimer}</p>
      </div>

      <div className="mb-6">
        <label htmlFor="agree" className="flex items-start cursor-pointer text-sm text-gray-700">
          <input
            type="checkbox"
            id="agree"
            checked={agreed}
            onChange={(e) => setAgreed(e.target.checked)}
            className="form-checkbox h-5 w-5 text-primary rounded border-gray-300 focus:ring-primary-dark mt-0.5 mr-2 flex-shrink-0"
          />
          <span>{strings.agreeCheckboxLabel}</span>
        </label>
      </div>

      <div className="flex flex-col sm:flex-row justify-between gap-3">
        <button
          onClick={onBack}
          className="w-full sm:w-auto bg-gray-200 text-gray-700 font-medium py-2.5 px-6 rounded-lg hover:bg-gray-300 transition duration-150 text-sm"
        >
          {strings.backButton}
        </button>
        <button
          onClick={onProceed}
          disabled={!agreed}
          className="w-full sm:w-auto bg-primary text-white font-semibold py-2.5 px-6 rounded-lg shadow-md hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50 transition duration-150 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center text-sm"
        >
          <CheckBadgeIcon className="w-5 h-5 mr-1.5" />
          {strings.proceedButton}
        </button>
      </div>
    </div>
  );
};

export default InstructionsScreen;
