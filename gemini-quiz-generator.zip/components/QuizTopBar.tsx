
import React from 'react';

// Simple Icons
const ClockIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const FullScreenEnterIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 ${props.className}`}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75v4.5m0-4.5h-4.5m4.5 0L15 9m5.25 11.25v-4.5m0 4.5h-4.5m4.5 0L15 15" />
    </svg>
);

const FullScreenExitIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 ${props.className}`}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 9V4.5M9 9H4.5M9 9L3.75 3.75M9 15v4.5M9 15H4.5M9 15l-5.25 5.25M15 9V4.5M15 9h4.5M15 9l5.25-5.25M15 15v4.5M15 15h4.5M15 15l5.25 5.25" />
    </svg>
);

const PlayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.348a1.125 1.125 0 010 1.971l-11.54 6.347a1.125 1.125 0 01-1.667-.985V5.653z" />
  </svg>
);

const PauseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25v13.5m-7.5-13.5v13.5" />
  </svg>
);


interface QuizTopBarProps {
  displayTitle: string; // Changed from quizTopic
  timeLeft: number;
  autoNextEnabled: boolean;
  onToggleAutoNext: () => void;
  onFullScreenToggle: () => void;
  isFullScreen: boolean;
  isTimerPaused: boolean;
  onToggleTimerPause: () => void;
}

const QuizTopBar: React.FC<QuizTopBarProps> = ({
  displayTitle,
  timeLeft,
  autoNextEnabled,
  onToggleAutoNext,
  onFullScreenToggle,
  isFullScreen,
  isTimerPaused,
  onToggleTimerPause,
}) => {
  const minutes = Math.floor(timeLeft / 60).toString().padStart(2, '0');
  const seconds = (timeLeft % 60).toString().padStart(2, '0');

  return (
    <div className="bg-primary text-white p-3 shadow-md flex items-center justify-between sticky top-0 z-20">
      <h1 
        className="text-lg font-semibold truncate flex-shrink-0 pr-2"
        title={displayTitle}
      >
        {displayTitle}
      </h1>

      <div className="flex-grow text-center text-xs sm:text-sm font-medium hidden md:block px-2">
        Keep Patience, Do Best and Good luck!
      </div>

      <div className="flex items-center space-x-2 md:space-x-3 flex-shrink-0">
        <div className="flex items-center bg-primary-dark px-2 py-1 rounded">
            <ClockIcon className="text-white mr-1" /> 
            <span className="text-sm md:text-base font-medium mr-2">{minutes}:{seconds}</span>
            <button
                onClick={onToggleTimerPause}
                className="p-0.5 rounded-full hover:bg-blue-700 focus:outline-none focus:ring-1 ring-offset-1 ring-offset-primary-dark focus:ring-white"
                title={isTimerPaused ? "Resume Timer" : "Pause Timer"}
                aria-label={isTimerPaused ? "Resume Timer" : "Pause Timer"}
            >
                {isTimerPaused ? <PlayIcon className="text-white" /> : <PauseIcon className="text-white" />}
            </button>
        </div>

        <div className="flex items-center space-x-1">
          <span className="text-xs hidden sm:inline">Auto-Next:</span>
          <button
            onClick={onToggleAutoNext}
            className={`relative inline-flex items-center h-5 w-9 sm:h-6 sm:w-11 rounded-full transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-primary-dark focus:ring-white ${
              autoNextEnabled ? 'bg-green-400' : 'bg-gray-400'
            }`}
            title={autoNextEnabled ? "Disable Auto-Next" : "Enable Auto-Next"}
            aria-pressed={autoNextEnabled}
          >
            <span className="sr-only">Toggle Auto-Next Question</span>
            <span
              className={`inline-block w-3 h-3 sm:w-4 sm:h-4 transform bg-white rounded-full transition-transform duration-200 ease-in-out ${
                autoNextEnabled ? 'translate-x-5 sm:translate-x-6' : 'translate-x-1'
              }`}
            />
          </button>
        </div>
        
        <button
          onClick={onFullScreenToggle}
          className="p-1 sm:p-1.5 rounded-full hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-offset-primary-dark focus:ring-white"
          title={isFullScreen ? "Exit Full Screen" : "Enter Full Screen"}
        >
          {isFullScreen ? <FullScreenExitIcon className="text-white" /> : <FullScreenEnterIcon className="text-white" />}
        </button>
      </div>
    </div>
  );
};

export default QuizTopBar;