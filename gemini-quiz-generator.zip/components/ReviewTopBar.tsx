import React from 'react';
import { ReviewScreenFilterState, Language } from '../types';
import { SUPPORTED_LANGUAGES } from '../constants';

// Icons (Heroicons style)
const FilterIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 mr-2 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6h9.75M10.5 12h9.75m-9.75 6h9.75M3.75 6H7.5m3 6H7.5m3 6H7.5m-3.75 0h.008v.008H3.75v-.008zm0-6h.008v.008H3.75v-.008zm0-6h.008v.008H3.75V6z" />
  </svg>
);
const XMarkIconSolid: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props} className={`w-5 h-5 ${props.className}`}>
    <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
  </svg>
);


interface ReviewTopBarProps {
  quizTitle: string;
  currentLanguage: Language;
  showFilterDropdown: boolean;
  setShowFilterDropdown: React.Dispatch<React.SetStateAction<boolean>>;
  activeFilters: ReviewScreenFilterState;
  toggleFilter: (filterKey: keyof ReviewScreenFilterState) => void;
  resetFilters: () => void;
  filterCounts: { correct: number; incorrect: number; unattempted: number };
  onExitReview: () => void;
}

const ReviewTopBar: React.FC<ReviewTopBarProps> = ({
  quizTitle,
  currentLanguage,
  showFilterDropdown,
  setShowFilterDropdown,
  activeFilters,
  toggleFilter,
  resetFilters,
  filterCounts,
  onExitReview,
}) => {
  const languageName = SUPPORTED_LANGUAGES.find(l => l.code === currentLanguage)?.nativeName || 'Language';
  
  return (
    <div className="bg-primary text-white p-3 shadow-md flex items-center justify-between sticky top-0 z-20 rounded-t-lg">
      <h1 className="text-lg font-semibold truncate flex-shrink-0 max-w-[calc(100%-280px)] sm:max-w-[calc(100%-320px)] pr-2" title={quizTitle}>
        Review: {quizTitle} ({languageName})
      </h1>

      <div className="flex items-center space-x-3">
        <div className="relative">
          <button
            onClick={() => setShowFilterDropdown(!showFilterDropdown)}
            className="flex items-center px-3 py-1.5 bg-primary-dark text-white rounded-md hover:bg-blue-700 transition duration-150 text-sm"
            title="Filter Questions"
          >
            <FilterIcon className="text-white" /> Filter
          </button>
          {showFilterDropdown && (
            <div className="absolute right-0 mt-2 w-64 bg-white rounded-md shadow-xl z-30 p-4 border border-gray-200 text-gray-700">
              <div className="flex justify-between items-center mb-2">
                <p className="font-semibold text-sm">Filter by Status:</p>
                <button onClick={() => setShowFilterDropdown(false)} className="text-gray-400 hover:text-gray-600">
                    <XMarkIconSolid />
                </button>
              </div>
              {(Object.keys(activeFilters) as Array<keyof ReviewScreenFilterState>).map(key => (
                <label key={key} className="flex items-center justify-between mb-1.5 cursor-pointer p-1.5 hover:bg-gray-100 rounded text-sm">
                  <span className="capitalize">{key}</span>
                  <div>
                    <span className="text-xs text-gray-500 mr-2">({filterCounts[key]})</span>
                    <input 
                        type="checkbox" 
                        checked={activeFilters[key]} 
                        onChange={() => toggleFilter(key)} 
                        className="form-checkbox h-4 w-4 text-primary rounded border-gray-300 focus:ring-primary-dark focus:ring-offset-0" 
                    />
                  </div>
                </label>
              ))}
              <button
                onClick={() => { resetFilters(); setShowFilterDropdown(false);}}
                className="w-full mt-3 px-3 py-1.5 bg-gray-600 text-white text-xs rounded-md hover:bg-gray-700 transition duration-150"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>
        <button
          onClick={onExitReview}
          className="px-3 py-1.5 bg-red-500 text-white rounded-md hover:bg-red-600 transition duration-150 text-sm"
          title="Back to Quiz Summary"
        >
          Exit Review
        </button>
      </div>
    </div>
  );
};

export default ReviewTopBar;
