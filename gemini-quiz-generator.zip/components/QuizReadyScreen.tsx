

import React from 'react';

// Icons
const PlayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.348a1.125 1.125 0 010 1.971l-11.54 6.347a1.125 1.125 0 01-1.667-.985V5.653z" />
  </svg>
);
const ArrowDownTrayIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
  </svg>
);
const ArrowUturnLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
  </svg>
);
const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);


interface QuizReadyScreenProps {
  quizTitle: string;
  appName: string; 
  onStartQuiz: () => void;
  onDownloadQuiz: () => void;
  onGoBack: () => void;
  isAutoDownloaded?: boolean;
}

const QuizReadyScreen: React.FC<QuizReadyScreenProps> = ({ quizTitle, appName, onStartQuiz, onDownloadQuiz, onGoBack, isAutoDownloaded }) => {
  return (
    <div className="max-w-md mx-auto my-10 p-8 bg-white rounded-xl shadow-custom-medium text-center">
      <h1 className="text-3xl font-bold text-gray-800 mb-4">Quiz Ready!</h1>

      {isAutoDownloaded && (
        <div className="bg-green-100 border border-green-200 text-green-800 px-4 py-3 rounded-lg relative mb-6 text-sm flex items-center justify-center" role="alert">
          <CheckCircleIcon className="w-5 h-5 mr-2" />
          <span className="block sm:inline">Your quiz download has started automatically.</span>
        </div>
      )}

      <p className="text-lg text-gray-700 mb-1">Your quiz from <span className="font-semibold text-primary">{appName}</span> on</p>
      <p className="text-2xl font-semibold text-primary mb-8">"{quizTitle}"</p>
      <p className="text-md text-gray-600 mb-6">What would you like to do next?</p>
      
      <div className="space-y-4">
        <button
          onClick={onStartQuiz}
          className="w-full bg-green-500 text-white font-semibold py-3 px-4 rounded-lg shadow-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50 transition duration-150 flex items-center justify-center text-lg"
        >
          <PlayIcon className="w-6 h-6 mr-2" />
          Start Quiz Online
        </button>
        <button
          onClick={onDownloadQuiz}
          className="w-full bg-blue-500 text-white font-semibold py-3 px-4 rounded-lg shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-150 flex items-center justify-center text-lg"
        >
          <ArrowDownTrayIcon className="w-6 h-6 mr-2" />
          Download as HTML
        </button>
         <button
          onClick={onGoBack}
          className="w-full bg-gray-500 text-white font-semibold py-3 px-4 rounded-lg shadow-md hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50 transition duration-150 flex items-center justify-center text-lg mt-4"
        >
          <ArrowUturnLeftIcon className="w-6 h-6 mr-2" />
          Create New Quiz
        </button>
      </div>
       <p className="text-xs text-gray-500 mt-4">You can download the quiz as an HTML file for offline viewing and printing.</p>
    </div>
  );
};

export default QuizReadyScreen;