

import React from 'react';
import { Question } from '../types';

interface QuestionContentProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  selectedOptionIndex: number | null;
  onSelectOption: (optionIndex: number) => void;
  isSubmitted: boolean; 
}

const QuestionContent: React.FC<QuestionContentProps> = ({
  question,
  questionNumber,
  totalQuestions,
  selectedOptionIndex,
  onSelectOption,
  isSubmitted, 
}) => {
  
  const getOptionClasses = (optionIdx: number): string => {
    let baseClass = "text-left p-3 md:p-3.5 mb-2 rounded-lg border border-gray-300 transition-all duration-200 ease-in-out w-full text-sm md:text-base"; // Adjusted padding
    baseClass += " hover:bg-blue-50 hover:border-primary hover:shadow-sm";
    if (selectedOptionIndex === optionIdx) {
      baseClass += " bg-primary text-white border-primary-dark font-medium shadow-md ring-1 ring-primary-dark";
    } else {
      baseClass += " bg-white text-gray-700";
    }
    return baseClass;
  };

  return (
    <div className="flex-grow"> 
      <h3 className="text-base md:text-lg font-medium text-gray-600 mb-1">
        Question {questionNumber} <span className="text-xs text-gray-400">of {totalQuestions}</span>
      </h3>
      {question.reference && (
        <div className="bg-indigo-50 border-l-4 border-indigo-400 p-2 mb-2 rounded text-xs text-indigo-700">
          {question.reference}
        </div>
      )}
      <p className="text-md md:text-lg text-gray-800 mb-5 font-semibold leading-snug">{question.text}</p> {/* Increased mb */}
      
      <div className="options-grid grid grid-cols-1 gap-x-3 gap-y-1.5"> {/* Always grid-cols-1, adjusted gap */}
        {question.options.map((option, idx) => (
          <button
            key={idx}
            className={getOptionClasses(idx)}
            onClick={() => onSelectOption(idx)}
            disabled={isSubmitted} 
            aria-pressed={selectedOptionIndex === idx}
          >
            <span className={`font-semibold mr-2 ${selectedOptionIndex === idx ? 'text-white': 'text-primary'}`}>{String.fromCharCode(65 + idx)}.</span> 
            {option}
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuestionContent;
