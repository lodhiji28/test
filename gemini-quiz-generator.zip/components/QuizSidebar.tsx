import React from 'react';
import { Question, UserAnswer, QuestionStatus } from '../types';
import QuizPagination from './QuizPagination';
import { DEFAULT_QUIZ_SECTION_NAME } from '../constants';

// Icons for Sidebar
const UserCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-8 h-8 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);
const CheckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props} className={`w-4 h-4 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
  </svg>
);
const XMarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
 <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props} className={`w-4 h-4 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);
const EyeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-4 h-4 ${props.className}`}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);
const BookmarkIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-4 h-4 ${props.className}`}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17.593 3.322c1.1.128 1.907 1.077 1.907 2.185V21L12 17.25 4.5 21V5.507c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0111.186 0z" />
    </svg>
);
const PaperAirplaneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 mr-2 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
  </svg>
);
const ChatBubbleLeftRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props} className={`w-5 h-5 mr-2 ${props.className}`}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3.68-3.091a4.501 4.501 0 00-1.053-.478H8.25c-1.135 0-2.097-.847-2.193-1.98-.027-.34-.052-.68-.072-1.02v-3.091l3.68 3.091c.195.164.43.298.68.388a4.501 4.501 0 004.005-1.628A4.5 4.5 0 0016.5 9.75h1.5a4.5 4.5 0 001.628-1.239zM6.023 9.013L2.446 6.318l-.002-.002a1.5 1.5 0 01.6-2.588c.341-.17.712-.255 1.078-.255h13.713c1.135 0 2.097.847 2.193 1.98.027.34.052-.68.072 1.02v2.711l-3.68-3.091A4.501 4.501 0 0012.25 4.5h-1.5a4.5 4.5 0 00-1.628 1.239z" />
  </svg>
);


interface QuizSidebarProps {
  userAnswers: UserAnswer[];
  questions: Question[];
  quizTopic: string; 
  currentQuestionIndex: number;
  onNavigate: (index: number) => void;
  onSubmitQuiz: () => void;
  isTimerPaused: boolean;
}

const QuizSidebar: React.FC<QuizSidebarProps> = ({
  userAnswers,
  questions,
  quizTopic,
  currentQuestionIndex,
  onNavigate,
  onSubmitQuiz,
  isTimerPaused,
}) => {
  const sectionName = quizTopic || DEFAULT_QUIZ_SECTION_NAME;

  const answeredCount = userAnswers.filter(ua => ua.status === QuestionStatus.Answered || ua.status === QuestionStatus.AnsweredAndMarked).length;
  const notAnsweredCount = userAnswers.filter(ua => ua.status === QuestionStatus.NotAnswered).length;
  const markedCount = userAnswers.filter(ua => ua.status === QuestionStatus.MarkedForReview || ua.status === QuestionStatus.AnsweredAndMarked).length;
  const notVisitedCount = userAnswers.filter(ua => ua.status === QuestionStatus.NotVisited).length;

  return (
    <div className="w-full md:w-72 lg:w-80 bg-gray-50 p-3 border-l border-gray-300 flex flex-col h-full">
      {/* User Info Placeholder & Action Buttons */}
      <div className="p-2 border-b border-gray-200 mb-3">
        <div className="flex items-center mb-3">
            <UserCircleIcon className="text-gray-400 mr-2" />
            <span className="text-sm font-medium text-gray-700">Future Officer</span>
        </div>
        <div className="space-y-2">
            <a
            href="https://t.me/LODHIJI27"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full flex items-center justify-center bg-sky-500 text-white text-sm font-medium py-2 px-3 rounded-md hover:bg-sky-600 transition duration-150"
            >
            <ChatBubbleLeftRightIcon /> Contact Admin
            </a>
            <button
            onClick={onSubmitQuiz}
            disabled={isTimerPaused}
            className="w-full flex items-center justify-center bg-primary text-white text-sm font-medium py-2 px-3 rounded-md hover:bg-primary-dark transition duration-150 disabled:opacity-60 disabled:cursor-not-allowed"
            >
            <PaperAirplaneIcon /> Submit Test
            </button>
        </div>
      </div>

      {/* Question Status Summary */}
      <div className="grid grid-cols-2 gap-1.5 text-xs p-1 mb-3">
        <div className="flex items-center p-1 bg-green-100 text-green-700 rounded-sm">
          <CheckIcon className="mr-1" /> Answered: <span className="font-semibold ml-auto">{answeredCount}</span>
        </div>
        <div className="flex items-center p-1 bg-red-100 text-red-700 rounded-sm">
          <XMarkIcon className="mr-1" /> Not Answered: <span className="font-semibold ml-auto">{notAnsweredCount}</span>
        </div>
        <div className="flex items-center p-1 bg-yellow-100 text-yellow-700 rounded-sm">
          <EyeIcon className="mr-1" /> Not Visited: <span className="font-semibold ml-auto">{notVisitedCount}</span>
        </div>
        <div className="flex items-center p-1 bg-blue-100 text-blue-700 rounded-sm">
          <BookmarkIcon className="mr-1" /> Marked: <span className="font-semibold ml-auto">{markedCount}</span>
        </div>
      </div>
      
      {/* Scrollable Pagination Area */}
      <div className="p-2 border-t border-b border-gray-200 flex-1 overflow-y-auto mb-3 min-h-0">
        <p className="text-sm font-semibold text-center text-primary mb-2 sticky top-0 bg-gray-50 py-1 z-10">SECTION: {sectionName}</p>
        <QuizPagination
          totalQuestions={questions.length}
          currentQuestionIndex={currentQuestionIndex}
          userAnswers={userAnswers} 
          questions={questions}    
          onNavigate={onNavigate}
          isSubmitted={false} 
        />
      </div>
      
      {/* Removed buttons from here, moved to top */}
    </div>
  );
};

export default QuizSidebar;