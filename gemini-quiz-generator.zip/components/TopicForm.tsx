import React, { useState, useRef, useEffect } from 'react';
import { Language } from '../types';
import { SUPPORTED_LANGUAGES, QUESTION_COUNT_OPTIONS, DEFAULT_APP_NAME, DEFAULT_YOUTUBE_LINK, DEFAULT_TELEGRAM_LINK } from '../constants';

// Icons
const LightBulbIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.311V21m0 0H9m3-3.75V6.75m0-3a3 3 0 00-3 3h6a3 3 0 00-3-3z" /></svg>
);
const DocumentTextIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
);
const PresentationChartBarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M3.375 19.5h17.25m-17.25 0a1.125 1.125 0 01-1.125-1.125M3.375 19.5h7.5M7.5 14.25m0 0V5.25m0 9V5.25m0 0s0-4.5 3.75-4.5M7.5 14.25E10 10.5m0 0s2.25-4.5 3.75-4.5M15 14.25V5.25m0 9V5.25m0 0s0-4.5-3.75-4.5M15 14.25A3.375 3.375 0 0118.375 10.5m0 0s2.25-4.5 3.75-4.5m0 0a1.125 1.125 0 011.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-17.25c-.621 0-1.125-.504-1.125-1.125V18M14.25 4.5l-3 3m0 0l-3-3m3 3V1.5M12 12.75a1.125 1.125 0 110-2.25 1.125 1.125 0 010 2.25z" /></svg>
);
const CogIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12a7.5 7.5 0 0015 0m-15 0a7.5 7.5 0 1115 0m-15 0H3m18 0h-1.5m-15 0c0-1.078.166-2.129.472-3.139M12 4.5V3m0 1.5V6m0-1.5a7.5 7.5 0 100 15M12 21v-1.5m0-1.5V18m0 1.5a7.5 7.5 0 110-15m3.361 2.021a2.476 2.476 0 01.139-.076M20.028 15.36a2.476 2.476 0 01-.076-.139M9.972 8.64a2.476 2.476 0 01.076.139m0 6.582a2.476 2.476 0 01-.139.076M7.5 12a4.5 4.5 0 014.5-4.5M16.5 12a4.5 4.5 0 01-4.5 4.5m-4.5 0a4.5 4.5 0 004.5 4.5m4.5-4.5a4.5 4.5 0 00-4.5-4.5M12 12a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5z" /></svg>
);

interface TopicFormProps {
  onTopicSubmit: (topic: string) => void;
  onTextSubmit: (pastedText: string, customInstructions: string) => void;
  onPresentationSubmit: (input: string, type: 'topic' | 'text', customInstructions?: string) => void;
  error: string | null;
  isLoading: boolean;
  currentLanguage: Language;
  onLanguageChange: (language: Language) => void;
  currentNumberOfQuestions: number;
  onNumberOfQuestionsChange: (count: number) => void;
  numberOfQuestionsOptions: number[];
  currentAppName: string;
  onAppNameChange: (name: string) => void;
  currentYoutubeLink: string;
  onYoutubeLinkChange: (link: string) => void;
  currentTelegramLink: string;
  onTelegramLinkChange: (link: string) => void;
}

type ActiveTab = 'topic' | 'text' | 'presentation' | 'settings';

const TopicForm: React.FC<TopicFormProps> = ({
  onTopicSubmit,
  onTextSubmit,
  onPresentationSubmit,
  error,
  isLoading,
  currentLanguage,
  onLanguageChange,
  currentNumberOfQuestions,
  onNumberOfQuestionsChange,
  numberOfQuestionsOptions,
  currentAppName,
  onAppNameChange,
  currentYoutubeLink,
  onYoutubeLinkChange,
  currentTelegramLink,
  onTelegramLinkChange,
}) => {
  const [topic, setTopic] = useState('');
  const [pastedText, setPastedText] = useState('');
  const [customInstructions, setCustomInstructions] = useState('');
  const [presentationInput, setPresentationInput] = useState('');
  const [presentationType, setPresentationType] = useState<'topic' | 'text'>('topic');
  const [presentationCustomInstructions, setPresentationCustomInstructions] = useState('');
  const [activeTab, setActiveTab] = useState<ActiveTab>('topic');
  
  const topicInputRef = useRef<HTMLInputElement>(null);
  const pastedTextInputRef = useRef<HTMLTextAreaElement>(null);
  const presentationInputRef = useRef<HTMLTextAreaElement>(null);


  useEffect(() => {
    if (activeTab === 'topic' && topicInputRef.current) {
      topicInputRef.current.focus();
    } else if (activeTab === 'text' && pastedTextInputRef.current) {
      pastedTextInputRef.current.focus();
    } else if (activeTab === 'presentation' && presentationInputRef.current) {
      presentationInputRef.current.focus();
    }
  }, [activeTab]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    if (activeTab === 'topic') {
      if (topic.trim()) onTopicSubmit(topic.trim());
    } else if (activeTab === 'text') {
      if (pastedText.trim()) onTextSubmit(pastedText.trim(), customInstructions.trim());
    } else if (activeTab === 'presentation') {
      if (presentationInput.trim()) {
        onPresentationSubmit(presentationInput.trim(), presentationType, presentationCustomInstructions.trim());
      }
    }
  };
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'topic':
        return (
          <>
            <label htmlFor="topic" className="block text-sm font-medium text-gray-700 mb-1">Quiz Topic</label>
            <input
              type="text"
              id="topic"
              ref={topicInputRef}
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., 'Indian History', 'Quantum Physics Basics'"
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
              disabled={isLoading}
            />
            <button type="submit" className="mt-6 w-full bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50 transition duration-150 disabled:opacity-60" disabled={isLoading || !topic.trim()}>
              {isLoading ? 'Generating Quiz...' : 'Generate Quiz from Topic'}
            </button>
          </>
        );
      case 'text':
        return (
          <>
            <label htmlFor="pastedText" className="block text-sm font-medium text-gray-700 mb-1">Paste Your Text</label>
            <textarea
              id="pastedText"
              ref={pastedTextInputRef}
              value={pastedText}
              onChange={(e) => setPastedText(e.target.value)}
              placeholder="Paste any text content here to generate a quiz..."
              rows={8}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
              disabled={isLoading}
            />
            <label htmlFor="customInstructions" className="block text-sm font-medium text-gray-700 mt-3 mb-1">Custom Instructions (Optional)</label>
            <input
              type="text"
              id="customInstructions"
              value={customInstructions}
              onChange={(e) => setCustomInstructions(e.target.value)}
              placeholder="e.g., 'Focus on dates', 'Create easy questions'"
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
              disabled={isLoading}
            />
            <button type="submit" className="mt-6 w-full bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50 transition duration-150 disabled:opacity-60" disabled={isLoading || !pastedText.trim()}>
              {isLoading ? 'Generating Quiz...' : 'Generate Quiz from Text'}
            </button>
          </>
        );
      case 'presentation':
        return (
          <>
            <label htmlFor="presentationType" className="block text-sm font-medium text-gray-700 mb-1">Presentation Based On:</label>
            <select
                id="presentationType"
                value={presentationType}
                onChange={(e) => setPresentationType(e.target.value as 'topic' | 'text')}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150 mb-3"
                disabled={isLoading}
            >
                <option value="topic">Topic</option>
                <option value="text">Pasted Text</option>
            </select>
            <label htmlFor="presentationInput" className="block text-sm font-medium text-gray-700 mb-1">
                {presentationType === 'topic' ? 'Presentation Topic' : 'Paste Text for Presentation'}
            </label>
            <textarea
              id="presentationInput"
              ref={presentationInputRef}
              value={presentationInput}
              onChange={(e) => setPresentationInput(e.target.value)}
              placeholder={presentationType === 'topic' ? "e.g., 'Renewable Energy Sources'" : "Paste text for presentation..."}
              rows={presentationType === 'topic' ? 2 : 6}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
              disabled={isLoading}
            />
            <label htmlFor="presentationCustomInstructions" className="block text-sm font-medium text-gray-700 mt-3 mb-1">Custom Instructions (Optional)</label>
            <input
              type="text"
              id="presentationCustomInstructions"
              value={presentationCustomInstructions}
              onChange={(e) => setPresentationCustomInstructions(e.target.value)}
              placeholder="e.g., 'Include a Q&A slide', 'Keep it formal'"
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
              disabled={isLoading}
            />
            <button type="submit" className="mt-6 w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-green-600 focus:ring-opacity-50 transition duration-150 disabled:opacity-60" disabled={isLoading || !presentationInput.trim()}>
              {isLoading ? 'Generating Presentation...' : 'Generate Presentation'}
            </button>
          </>
        );
        case 'settings':
            return (
                <>
                    <h3 className="text-lg font-semibold text-gray-700 mb-3">Quiz & App Settings</h3>
                    
                    <div className="mb-4">
                        <label htmlFor="language" className="block text-sm font-medium text-gray-700 mb-1">Quiz Language</label>
                        <select
                        id="language"
                        value={currentLanguage}
                        onChange={(e) => onLanguageChange(e.target.value as Language)}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
                        disabled={isLoading}
                        >
                        {SUPPORTED_LANGUAGES.map(lang => (
                            <option key={lang.code} value={lang.code}>{lang.nativeName} ({lang.name})</option>
                        ))}
                        </select>
                    </div>

                    <div className="mb-4">
                        <label htmlFor="numQuestions" className="block text-sm font-medium text-gray-700 mb-1">Number of Questions</label>
                        <select
                        id="numQuestions"
                        value={currentNumberOfQuestions}
                        onChange={(e) => onNumberOfQuestionsChange(Number(e.target.value))}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
                        disabled={isLoading}
                        >
                        {numberOfQuestionsOptions.map(count => (
                            <option key={count} value={count}>{count} Questions</option>
                        ))}
                        </select>
                    </div>
                    
                    <div className="mb-4">
                        <label htmlFor="appName" className="block text-sm font-medium text-gray-700 mb-1">App Name</label>
                        <input
                            type="text"
                            id="appName"
                            value={currentAppName}
                            onChange={(e) => onAppNameChange(e.target.value)}
                            placeholder="e.g., My Quiz App"
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
                            disabled={isLoading}
                        />
                    </div>
                    <div className="mb-4">
                        <label htmlFor="youtubeLink" className="block text-sm font-medium text-gray-700 mb-1">YouTube Link</label>
                        <input
                            type="url"
                            id="youtubeLink"
                            value={currentYoutubeLink}
                            onChange={(e) => onYoutubeLinkChange(e.target.value)}
                            placeholder="https://youtube.com/yourchannel"
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
                            disabled={isLoading}
                        />
                    </div>
                    <div>
                        <label htmlFor="telegramLink" className="block text-sm font-medium text-gray-700 mb-1">Telegram Link</label>
                        <input
                            type="url"
                            id="telegramLink"
                            value={currentTelegramLink}
                            onChange={(e) => onTelegramLinkChange(e.target.value)}
                            placeholder="https://t.me/yourgroup"
                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-primary focus:border-primary transition duration-150"
                            disabled={isLoading}
                        />
                    </div>
                     <p className="mt-6 text-xs text-gray-500 text-center">These settings will apply to the next generated quiz or presentation.</p>
                </>
            );
    }
  };

  const getTabClass = (tabName: ActiveTab) => 
    `flex-1 py-2.5 px-2 text-center text-sm font-medium cursor-pointer rounded-t-md border-b-2 transition-colors duration-150 ease-in-out
     ${activeTab === tabName 
       ? 'border-primary text-primary bg-blue-50' 
       : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-100'
     }`;

  return (
    <div className="max-w-xl mx-auto my-8 p-6 md:p-8 bg-white rounded-xl shadow-custom-xl">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-2">
        {currentAppName || DEFAULT_APP_NAME}
      </h1>
      <p className="text-sm text-center text-gray-500 mb-6">
        Generate Quizzes & Presentations Effortlessly with AI
      </p>

      <div className="flex border-b border-gray-200 mb-6">
        <button onClick={() => setActiveTab('topic')} className={getTabClass('topic')} aria-selected={activeTab === 'topic'}>
          <LightBulbIcon className="w-5 h-5 mx-auto mb-0.5"/> Topic Quiz
        </button>
        <button onClick={() => setActiveTab('text')} className={getTabClass('text')} aria-selected={activeTab === 'text'}>
          <DocumentTextIcon className="w-5 h-5 mx-auto mb-0.5"/> Text Quiz
        </button>
        <button onClick={() => setActiveTab('presentation')} className={getTabClass('presentation')} aria-selected={activeTab === 'presentation'}>
          <PresentationChartBarIcon className="w-5 h-5 mx-auto mb-0.5" /> Presentation
        </button>
         <button onClick={() => setActiveTab('settings')} className={getTabClass('settings')} aria-selected={activeTab === 'settings'}>
          <CogIcon className="w-5 h-5 mx-auto mb-0.5" /> Settings
        </button>
      </div>
      
      {error && (
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md shadow-sm" role="alert">
          <p className="font-bold">Error</p>
          <p className="text-sm whitespace-pre-wrap">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {renderTabContent()}
      </form>
    </div>
  );
};

export default TopicForm;