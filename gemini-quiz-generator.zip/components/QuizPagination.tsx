
import React from 'react';
import { Question, UserAnswer, QuestionStatus } from '../types';

interface QuizPaginationProps {
  totalQuestions: number;
  currentQuestionIndex: number;
  userAnswers: UserAnswer[];
  questions: Question[]; // Needed to map userAnswer.questionId to actual question index if not already aligned
  onNavigate: (index: number) => void;
  isSubmitted: boolean; // To control appearance post-quiz submission if needed
}

const QuizPagination: React.FC<QuizPaginationProps> = ({
  totalQuestions,
  currentQuestionIndex,
  userAnswers,
  questions, // Assuming questions array is ordered by ID 0 to N-1
  onNavigate,
  isSubmitted,
}) => {
  const getBoxClasses = (questionListIndex: number): string => {
    // questionListIndex is the index in the 'questions' array, which we assume is 0 to N-1.
    // We need to find the UserAnswer corresponding to this question.
    const questionId = questions[questionListIndex].id;
    const userAnswer = userAnswers.find(ua => ua.questionId === questionId);

    let baseClass = "w-7 h-7 md:w-8 md:h-8 flex items-center justify-center text-xs md:text-sm font-medium border rounded cursor-pointer transition-all duration-150 ease-in-out shadow-sm";

    if (questionListIndex === currentQuestionIndex) {
      baseClass += " bg-primary text-white border-primary-dark scale-110 ring-2 ring-offset-1 ring-primary-dark";
    } else {
      // Default style for non-current questions
      baseClass += " bg-gray-100 text-gray-600 border-gray-300 hover:bg-gray-200 hover:border-gray-400";
    }

    // Apply styles based on QuestionStatus if not the current question
    if (userAnswer && questionListIndex !== currentQuestionIndex) {
      switch (userAnswer.status) {
        case QuestionStatus.NotVisited:
          baseClass = baseClass.replace("bg-gray-100", "bg-white").replace("border-gray-300", "border-gray-300").replace("text-gray-600", "text-gray-500"); // Default, unvisited
          break;
        case QuestionStatus.NotAnswered:
          baseClass = baseClass.replace("bg-gray-100", "bg-red-100").replace("border-gray-300", "border-red-300").replace("text-gray-600", "text-red-600"); // Visited, not answered
          break;
        case QuestionStatus.Answered:
          baseClass = baseClass.replace("bg-gray-100", "bg-green-100").replace("border-gray-300", "border-green-400").replace("text-gray-600", "text-green-700"); // Answered
          break;
        case QuestionStatus.MarkedForReview:
          baseClass = baseClass.replace("bg-gray-100", "bg-purple-100").replace("border-gray-300", "border-purple-400").replace("text-gray-600", "text-purple-700"); // Marked, not answered
          break;
        case QuestionStatus.AnsweredAndMarked:
          baseClass = baseClass.replace("bg-gray-100", "bg-blue-200").replace("border-gray-300", "border-blue-400").replace("text-gray-600", "text-blue-700"); // Answered and marked
          break;
        default:
          // Keep baseClass if status is unknown
          break;
      }
    }
    
    // Additional style for marked questions, can be combined with status colors
    if (userAnswer && userAnswer.isMarked && questionListIndex !== currentQuestionIndex) {
      baseClass += " ring-1 ring-purple-500 ring-offset-0"; // Example: purple ring for marked
    }
    
    // If submitted, you might want to override styles to show correct/incorrect
    if (isSubmitted && userAnswer && userAnswer.selectedOptionIndex !== null) {
        const question = questions[questionListIndex];
        if (userAnswer.selectedOptionIndex === question.correctIndex) {
            baseClass = baseClass.replace(/bg-\w+-100/g, "bg-green-500").replace(/border-\w+-400/g, "border-green-600").replace(/text-\w+-700/g, "text-white");
             if (questionListIndex === currentQuestionIndex) baseClass = baseClass.replace("ring-primary-dark", "ring-green-600");
        } else {
            baseClass = baseClass.replace(/bg-\w+-100/g, "bg-red-500").replace(/border-\w+-400/g, "border-red-600").replace(/text-\w+-700/g, "text-white");
            if (questionListIndex === currentQuestionIndex) baseClass = baseClass.replace("ring-primary-dark", "ring-red-600");
        }
    } else if (isSubmitted && userAnswer && userAnswer.selectedOptionIndex === null && questionListIndex !== currentQuestionIndex) {
         baseClass = baseClass.replace("bg-gray-100", "bg-yellow-200").replace("border-gray-300", "border-yellow-400").replace("text-gray-600", "text-yellow-700");
    }


    return baseClass;
  };

  return (
    <div className="grid grid-cols-5 gap-1.5 p-1"> {/* Adjusted gap and items per row for sidebar */}
      {Array.from({ length: totalQuestions }).map((_, index) => (
        <div
          key={questions[index].id} // Use question ID for key if available and stable
          className={getBoxClasses(index)}
          onClick={() => onNavigate(index)}
          role="button"
          tabIndex={0}
          aria-label={`Question ${index + 1}`}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onNavigate(index); }}
        >
          {index + 1}
        </div>
      ))}
    </div>
  );
};

export default QuizPagination;
