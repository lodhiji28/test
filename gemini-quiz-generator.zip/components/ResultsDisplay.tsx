
import React from 'react';
import { QuizResults } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, Text, ComposedChart } from 'recharts';

interface ResultsDisplayProps {
  results: QuizResults;
  onReview: () => void;
  onReattemptThisQuiz: () => void;
  onStartNewQuiz: () => void;
  youtubeLink: string;
  telegramLink: string;
}

const COLORS = {
  correct: '#28a745', // green
  incorrect: '#dc3545', // red
  unattempted: '#ffc107', // yellow
};

// Icons (Heroicons style or similar SVGs)
const SearchIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
  </svg>
);
const RefreshIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-0.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
  </svg>
);
const PlusCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m3-3H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const YouTubeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M10,15L15.19,12L10,9V15M21.56,7.17C21.69,7.64 21.78,8.27 21.84,9.07C21.91,9.87 21.94,10.56 21.94,11.16L22,12C22,14.19 21.84,15.8 21.56,16.83C21.31,17.73 20.73,18.31 19.83,18.56C19.36,18.69 18.73,18.78 17.93,18.84C17.13,18.91 16.44,18.94 15.84,18.94L15,19C12.81,19 11.2,18.84 10.17,18.56C9.27,18.31 8.69,17.73 8.44,16.83C8.31,16.36 8.22,15.73 8.16,14.93C8.09,14.13 8.06,13.44 8.06,12.84L8,12C8,9.81 8.16,8.2 8.44,7.17C8.69,6.27 9.27,5.69 10.17,5.44C10.64,5.31 11.27,5.22 12.07,5.16C12.87,5.09 13.56,5.06 14.16,5.06L15,5C17.19,5 18.8,5.16 19.83,5.44C20.73,5.69 21.31,6.27 21.56,7.17Z"></path>
    </svg>
);

const TelegramIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg viewBox="0 0 24 24" fill="currentColor" {...props}>
        <path d="M9.78,18.65L10.26,14.21L18.73,7.45M9.78,18.65L12.73,17.54L14.21,15.07L12.06,17.03M9.78,18.65L6.29,17.3L3.09,16.1L3.18,16.27C3.43,16.77 3.63,17.26 3.76,17.74C3.92,18.31 3.96,18.83 3.96,19.31C3.96,19.31 4,19.31 4,19.32L4,19.33C4,19.73 4.07,20.13 4.22,20.5C4.39,20.88 4.62,21.23 4.93,21.53C5.23,21.83 5.59,22.07 5.97,22.24C6.34,22.41 6.73,22.5 7.12,22.5C7.5,22.5 7.85,22.42 8.17,22.27C8.48,22.11 8.77,21.89 9.03,21.63C9.29,21.37 9.5,21.07 9.66,20.75C9.83,20.42 9.91,20.05 9.91,19.65L9.78,18.65M18.73,7.45L7.05,12.92L3,11.62L20.94,4.69L18.73,7.45Z"></path>
    </svg>
);


const getMotivationalFeedback = (percentage: number): { title: string; message: string; colorClass: string } => {
  if (percentage >= 85) {
    return { title: "Outstanding!", message: "Future Officer, you have a strong grasp of the material. Keep up the fantastic work and aim for perfection!", colorClass: "text-green-600" };
  } else if (percentage >= 70) {
    return { title: "Great Job!", message: "You're on the right track. Focus on reviewing the areas where you made mistakes, and you'll ace it next time!", colorClass: "text-blue-600" };
  } else if (percentage >= 50) {
    return { title: "Solid Effort!", message: "There's room for improvement. Carefully review the explanations for incorrect answers and re-attempt the quiz to solidify your understanding.", colorClass: "text-yellow-600" };
  } else {
    return { title: "Keep Going!", message: "Don't be discouraged! This is a learning opportunity. Dedicate more time to the topic, review concepts thoroughly, and try again. Success comes with perseverance!", colorClass: "text-red-600" };
  }
};

const CustomBarLabel: React.FC<any> = (props) => {
  const { x, y, width, value, fill } = props; 
  const textColor = (fill === COLORS.unattempted || fill === '#ffc107') ? '#4A5568' : '#ffffff'; 

  if (value === 0) return null;

  return (
    <Text 
      x={x + width / 2} 
      y={y - 8} 
      fill={textColor} 
      textAnchor="middle" 
      fontSize="12px" 
      fontWeight="bold"
    >
      {value}
    </Text>
  );
};


const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ 
    results, 
    onReview, 
    onReattemptThisQuiz, 
    onStartNewQuiz,
    youtubeLink,
    telegramLink 
}) => {
  
  const performanceData = [
    { name: 'Correct', value: results.correct, fill: COLORS.correct },
    { name: 'Incorrect', value: results.incorrect, fill: COLORS.incorrect },
    { name: 'Unattempted', value: results.unattempted, fill: COLORS.unattempted },
  ];

  const feedback = getMotivationalFeedback(results.percentage);

  return (
    <div className="max-w-5xl mx-auto my-6 p-4 md:p-6 bg-gradient-to-br from-gray-50 to-blue-50 rounded-xl shadow-custom-medium">
      <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-800 mb-4">Quiz Results</h2>
      
      <div className={`text-center my-6 p-6 rounded-xl shadow-xl border-2 ${feedback.colorClass.replace('text-', 'border-').replace('-600', '-400')} ${feedback.colorClass.replace('text-', 'bg-').replace('-600', '-50')}`}>
        <h3 className={`text-2xl md:text-3xl font-semibold mb-2 ${feedback.colorClass}`}>{feedback.title}</h3>
        <p className="text-md text-gray-700 mb-4 max-w-2xl mx-auto">{feedback.message}</p>
        <div className={`text-5xl md:text-7xl font-extrabold ${feedback.colorClass} tracking-tight`}>
          {results.score.toFixed(2)} / {results.totalQuestions}
        </div>
        <div className={`text-2xl md:text-3xl font-semibold ${feedback.colorClass} mt-1`}>
          ({results.percentage.toFixed(1)}%)
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Score Summary Card */}
        <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Score Summary</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between"><span>Total Questions:</span> <span className="font-medium text-gray-800">{results.totalQuestions}</span></div>
            <div className="flex justify-between text-green-600"><span>Correct Answers:</span> <span className="font-medium">{results.correct}</span></div>
            <div className="flex justify-between text-red-600"><span>Incorrect Answers:</span> <span className="font-medium">{results.incorrect}</span></div>
            <div className="flex justify-between text-yellow-600"><span>Unattempted:</span> <span className="font-medium">{results.unattempted}</span></div>
            <div className="flex justify-between text-red-500"><span>Negative Marking Applied:</span> <span className="font-medium">-{results.negativeMarksApplied.toFixed(2)}</span></div>
            <div className="flex justify-between text-blue-600 pt-2 border-t mt-2"><span>Avg Time/Attempted Q:</span> <span className="font-medium">{results.avgTimePerQuestion.toFixed(1)}s</span></div>
          </div>
        </div>

        {/* Performance Bar Chart Card */}
        <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
          <h3 className="text-xl font-semibold text-gray-700 mb-6 text-center">Performance Breakdown</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart 
                data={performanceData} 
                layout="vertical" 
                margin={{ top: 5, right: 25, left: 10, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" domain={[0, 'dataMax + 2']} allowDecimals={false} tick={{ fontSize: 12 }} />
              <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 12, fill: '#374151' }} />
              <Tooltip 
                cursor={{fill: 'rgba(200,200,200,0.1)'}}
                contentStyle={{backgroundColor: 'rgba(255,255,255,0.9)', borderRadius: '8px', borderColor: '#ccc'}}
                formatter={(value: number, name: string) => [`${value} (${((value / results.totalQuestions) * 100).toFixed(1)}%)`, name]} 
              />
              <Bar dataKey="value" barSize={35} radius={[0, 6, 6, 0]}>
                {performanceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
      
      {/* Time Analysis Chart Card */}
      {results.timePerQuestionDetailed.length > 0 && (
        <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 mb-8">
          <h3 className="text-xl font-semibold text-gray-700 mb-4">Time Analysis Per Question</h3>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={results.timePerQuestionDetailed.map((item, index) => ({
                name: `Q${index + 1}`,
                time: parseFloat(item.time.toFixed(1)),
                status: item.status,
            }))} 
            margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} />
              <YAxis label={{ value: 'Time (s)', angle: -90, position: 'insideLeft', fontSize: 12, fill: '#6b7280' }} tick={{ fontSize: 12 }} />
              <Tooltip 
                contentStyle={{backgroundColor: 'rgba(255,255,255,0.9)', borderRadius: '8px', borderColor: '#ccc'}}
                formatter={(value: number, name: string, props: any) => [`${value}s (${props.payload.status})`, "Time Spent"]} 
              />
              <Legend wrapperStyle={{fontSize: "12px"}}/>
              <Bar dataKey="time" name="Time Spent (s)" barSize={20}>
                {results.timePerQuestionDetailed.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[entry.status as keyof typeof COLORS] || '#cccccc'} />
                ))}
              </Bar>
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Social Engagement Card */}
      <div className="mt-8 p-6 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl shadow-lg text-center">
        <h3 className="text-2xl font-semibold mb-3">Enjoyed the Quiz? Boost Your Prep!</h3>
        <p className="mb-6 text-blue-100">
          Subscribe to our channel for more insightful content and join our Telegram for daily updates, discussions, and exclusive materials.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
          <a
            href={youtubeLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center bg-red-600 hover:bg-red-700 text-white font-medium py-2.5 px-5 rounded-lg transition duration-150 shadow-md min-w-[180px]"
          >
            <YouTubeIcon className="w-6 h-6 mr-2.5" />
            Subscribe on YouTube
          </a>
          <a
            href={telegramLink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center bg-sky-500 hover:bg-sky-600 text-white font-medium py-2.5 px-5 rounded-lg transition duration-150 shadow-md min-w-[180px]"
          >
            <TelegramIcon className="w-6 h-6 mr-2.5" />
            Join on Telegram
          </a>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row justify-center gap-4 mt-8">
        <button
          onClick={onReview}
          className="bg-primary text-white font-semibold py-3 px-6 rounded-full shadow-md hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-primary focus:ring-opacity-50 transition duration-150 flex items-center justify-center text-sm"
        >
          <SearchIcon className="w-5 h-5 mr-2"/>
          View Solutions
        </button>
        <button
          onClick={onReattemptThisQuiz}
          className="bg-blue-500 text-white font-semibold py-3 px-6 rounded-full shadow-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition duration-150 flex items-center justify-center text-sm"
        >
          <RefreshIcon className="w-5 h-5 mr-2"/>
          Re-attempt this Quiz
        </button>
        <button
          onClick={onStartNewQuiz}
          className="bg-gray-600 text-white font-semibold py-3 px-6 rounded-full shadow-md hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50 transition duration-150 flex items-center justify-center text-sm"
        >
          <PlusCircleIcon className="w-5 h-5 mr-2"/>
          Start New Quiz
        </button>
      </div>
    </div>
  );
};

export default ResultsDisplay;