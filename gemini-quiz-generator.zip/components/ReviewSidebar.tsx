import React from 'react';
import { Question, UserAnswer, QuizResults } from '../types';
import QuizPagination from './QuizPagination';

// --- Icon Imports (Heroicons style) ---
const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const XCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const MinusCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => ( 
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const ClockIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);
const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => ( 
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12L17 13.75M17 8.25L18.25 12M12 18.25L13.75 17M8.25 17L12 18.25" /></svg>
);
const CheckBadgeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => ( 
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.745 3.745 0 013.296-1.043A3.745 3.745 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.745 3.745 0 011.043 3.296A3.745 3.745 0 0121 12z" /></svg>
);
const ExclamationTriangleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => ( 
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>
);

interface ReviewSidebarProps {
  currentOriginalQuestion: Question | null;
  currentOriginalUserAnswer: UserAnswer | null;
  quizResults: QuizResults;
  
  questions: Question[]; 
  userAnswers: UserAnswer[]; 
  filteredQuestionIds: number[]; 
  currentQuestionDisplayIndex: number; 
  onPaginationClick: (indexInFilteredList: number) => void;
}

const ReviewSidebar: React.FC<ReviewSidebarProps> = ({
  currentOriginalQuestion,
  currentOriginalUserAnswer,
  quizResults,
  questions,
  userAnswers,
  filteredQuestionIds,
  currentQuestionDisplayIndex,
  onPaginationClick,
}) => {

  const getQuestionStatusInfo = () => {
    if (!currentOriginalQuestion || !currentOriginalUserAnswer) return { text: 'N/A', color: 'text-gray-500', iconClass: 'text-gray-500', icon: <MinusCircleIcon className="w-5 h-5 mr-1"/> };
    if (currentOriginalUserAnswer.selectedOptionIndex === null) return { text: 'Unattempted', color: 'text-yellow-600', iconClass: 'text-yellow-600', icon: <MinusCircleIcon className="w-5 h-5 mr-1"/> };
    if (currentOriginalUserAnswer.selectedOptionIndex === currentOriginalQuestion.correctIndex) return { text: 'Correct', color: 'text-green-600', iconClass: 'text-green-600', icon: <CheckCircleIcon className="w-5 h-5 mr-1" /> };
    return { text: 'Incorrect', color: 'text-red-600', iconClass: 'text-red-600', icon: <XCircleIcon className="w-5 h-5 mr-1" /> };
  };

  const getTimePerformanceInfo = () => {
    if (!currentOriginalUserAnswer || quizResults.avgTimePerQuestion <= 0) return { text: 'N/A', color: 'text-gray-500', iconClass: 'text-gray-500', icon: <ClockIcon className="w-5 h-5"/>};
    const timeTaken = currentOriginalUserAnswer.timeTakenSeconds;
    const avgTime = quizResults.avgTimePerQuestion;
    if (timeTaken < avgTime * 0.7) return { text: 'Superfast', color: 'text-purple-600', iconClass: 'text-purple-600', icon: <SparklesIcon className="w-5 h-5"/>};
    if (timeTaken > avgTime * 1.3) return { text: 'Slow', color: 'text-orange-500', iconClass: 'text-orange-500', icon: <ExclamationTriangleIcon className="w-5 h-5"/>};
    return { text: 'On Time', color: 'text-blue-600', iconClass: 'text-blue-600', icon: <CheckBadgeIcon className="w-5 h-5"/>};
  };

  const questionStatusInfo = getQuestionStatusInfo();
  const timePerformanceInfo = getTimePerformanceInfo();

  const questionsForPagination = questions.filter(q => filteredQuestionIds.includes(q.id));
  const userAnswersForPagination = questionsForPagination.map(fq => userAnswers.find(ua => ua.questionId === fq.id)!);


  return (
    <div className="w-full md:w-72 lg:w-80 bg-gray-100 p-3 border-l border-gray-300 flex flex-col gap-3 h-full rounded-r-lg">
      {/* Performance Card */}
      <div className="p-3 bg-white rounded-lg shadow-sm border border-gray-200">
        <h4 className="text-sm font-semibold text-gray-700 mb-2">Current Question ({currentOriginalQuestion ? currentOriginalQuestion.id + 1 : 'N/A'}) Performance:</h4>
        {currentOriginalQuestion && currentOriginalUserAnswer ? (
          <div className="text-xs space-y-1 text-gray-600">
            <p className={`flex items-center ${questionStatusInfo.color}`}> {React.cloneElement(questionStatusInfo.icon, { className: `w-4 h-4 mr-1.5 ${questionStatusInfo.iconClass}` })} Status: <span className="font-medium ml-1">{questionStatusInfo.text}</span></p>
            <p>Time Taken: <span className="font-medium">{currentOriginalUserAnswer.timeTakenSeconds.toFixed(1)}s</span></p>
            <p className={`flex items-center ${timePerformanceInfo.color}`}> {React.cloneElement(timePerformanceInfo.icon, { className: `w-4 h-4 mr-1.5 ${timePerformanceInfo.iconClass}` })} Speed: <span className="font-medium ml-1 ">{timePerformanceInfo.text}</span></p>
            <p>(Avg Time: {quizResults.avgTimePerQuestion.toFixed(1)}s)</p>
          </div>
        ) : (
          <p className="text-xs text-gray-500">No question selected or data unavailable.</p>
        )}
      </div>

      {/* Question Navigation Card - consumes remaining space and allows internal scroll */}
      <div className="p-3 bg-white rounded-lg shadow-sm border border-gray-200 flex-1 flex flex-col min-h-0">
        <h4 className="text-sm font-semibold text-gray-700 mb-2 text-center">Question Navigation</h4>
        {questionsForPagination.length > 0 ? (
           <div className="flex-1 overflow-y-auto min-h-0"> {/* This div scrolls */}
             <QuizPagination
                totalQuestions={questionsForPagination.length} 
                currentQuestionIndex={currentQuestionDisplayIndex}
                userAnswers={userAnswersForPagination} 
                questions={questionsForPagination} 
                onNavigate={onPaginationClick} 
                isSubmitted={true} 
            />
           </div>
        ) : (
          <p className="text-xs text-center text-gray-500 py-4">No questions match filters.</p>
        )}
      </div>
    </div>
  );
};

export default ReviewSidebar;