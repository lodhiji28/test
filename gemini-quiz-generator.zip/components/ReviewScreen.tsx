

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Question, UserAnswer, QuizResults, ReviewScreenFilterState, Language } from '../types';
import ReviewTopBar from './ReviewTopBar';
import ReviewSidebar from './ReviewSidebar';

// --- Icon Imports (Heroicons style) ---
const CheckCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const XCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const MinusCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => ( 
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);
const EyeIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);
const EyeSlashIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.243 4.243L6.228 6.228" />
  </svg>
);
const ChevronLeftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
  </svg>
);
const ChevronRightIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
  </svg>
);
const LightBulbIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}><path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.311V21m0 0H9m3-3.75V6.75m0-3a3 3 0 00-3 3h6a3 3 0 00-3-3z" /></svg>
);


interface ReviewScreenProps {
  quizTitle: string; // This will be displayTitle (App Name - Quiz Topic)
  questions: Question[];
  userAnswers: UserAnswer[]; 
  quizResults: QuizResults;
  onExitReview: () => void;
  currentLanguage: Language;
}

const ReviewScreen: React.FC<ReviewScreenProps> = ({
  quizTitle,
  questions,
  userAnswers,
  quizResults,
  onExitReview,
  currentLanguage
}) => {
  const [currentQuestionDisplayIndex, setCurrentQuestionDisplayIndex] = useState(0); 
  const [isExplanationVisible, setIsExplanationVisible] = useState(false);
  const [areOptionsVisible, setAreOptionsVisible] = useState(true); 
  const [isReattemptModeOn, setIsReattemptModeOn] = useState(false);
  const [reattemptAnswers, setReattemptAnswers] = useState<{ [key: number]: number | null }>({});
  const [showFilterDropdown, setShowFilterDropdown] = useState(false);
  const [activeFilters, setActiveFilters] = useState<ReviewScreenFilterState>({
    correct: true, incorrect: true, unattempted: true
  });

  const filteredQuestionIds = useMemo(() => {
    return questions
      .map(q => q.id)
      .filter(questionId => {
        const userAnswer = userAnswers.find(ua => ua.questionId === questionId);
        const question = questions.find(q => q.id === questionId);
        if (!userAnswer || !question) return false;

        const isCorrect = userAnswer.selectedOptionIndex === question.correctIndex;
        const isIncorrect = userAnswer.selectedOptionIndex !== null && userAnswer.selectedOptionIndex !== question.correctIndex;
        const isUnattempted = userAnswer.selectedOptionIndex === null;
        
        if (!activeFilters.correct && !activeFilters.incorrect && !activeFilters.unattempted) return true; 

        if (activeFilters.correct && isCorrect) return true;
        if (activeFilters.incorrect && isIncorrect) return true;
        if (activeFilters.unattempted && isUnattempted) return true;
        
        return false; 
      });
  }, [questions, userAnswers, activeFilters]);
  
  const currentOriginalQuestion = useMemo(() => {
    if (filteredQuestionIds.length === 0) return null;
    const questionId = filteredQuestionIds[currentQuestionDisplayIndex];
    return questions.find(q => q.id === questionId) || null;
  }, [currentQuestionDisplayIndex, filteredQuestionIds, questions]);

  useEffect(() => {
    if (filteredQuestionIds.length > 0 && currentQuestionDisplayIndex >= filteredQuestionIds.length) {
        setCurrentQuestionDisplayIndex(Math.max(0, filteredQuestionIds.length - 1));
    } else if (filteredQuestionIds.length === 0 && currentQuestionDisplayIndex !== 0) {
        setCurrentQuestionDisplayIndex(0);
    } else if (currentQuestionDisplayIndex < 0 && filteredQuestionIds.length > 0) {
         setCurrentQuestionDisplayIndex(0);
    }
  }, [filteredQuestionIds, currentQuestionDisplayIndex]);

  useEffect(() => {
    if (!isReattemptModeOn) setIsExplanationVisible(true);
    else setIsExplanationVisible(false);
  }, [currentOriginalQuestion, isReattemptModeOn]);

  const currentOriginalUserAnswer = useMemo(() => {
    if (!currentOriginalQuestion) return null;
    return userAnswers.find(ua => ua.questionId === currentOriginalQuestion.id) || null;
  }, [currentOriginalQuestion, userAnswers]);

  const handleNavigate = (direction: 'next' | 'prev') => {
    if (direction === 'next') {
      setCurrentQuestionDisplayIndex(prev => Math.min(prev + 1, filteredQuestionIds.length - 1));
    } else {
      setCurrentQuestionDisplayIndex(prev => Math.max(prev - 1, 0));
    }
    setAreOptionsVisible(true); 
    setIsExplanationVisible(false); 
  };
  
  const handlePaginationClick = (indexInFilteredList: number) => {
    setCurrentQuestionDisplayIndex(indexInFilteredList);
    setAreOptionsVisible(true); 
    setIsExplanationVisible(false); 
  };

  const handleReattemptOptionSelect = (optionIndex: number) => {
    if (!currentOriginalQuestion || !isReattemptModeOn) return;
    setReattemptAnswers(prev => ({ ...prev, [currentOriginalQuestion.id]: optionIndex }));
  };
  
  const getQuestionStatus = (question: Question, userAnswer: UserAnswer | null | undefined) => {
    if (!userAnswer || userAnswer.selectedOptionIndex === null) return { text: 'Unattempted', color: 'text-yellow-600', icon: <MinusCircleIcon className="w-5 h-5 mr-1"/> };
    if (userAnswer.selectedOptionIndex === question.correctIndex) return { text: 'Correct', color: 'text-green-600', icon: <CheckCircleIcon className="w-5 h-5 mr-1" /> };
    return { text: 'Incorrect', color: 'text-red-600', icon: <XCircleIcon className="w-5 h-5 mr-1" /> };
  };

  const toggleFilter = (filterKey: keyof ReviewScreenFilterState) => {
    setActiveFilters(prev => ({ ...prev, [filterKey]: !prev[filterKey] }));
  };
  const resetFilters = () => {
    setActiveFilters({ correct: true, incorrect: true, unattempted: true });
  };

  const correctCount = userAnswers.filter(ua => questions.find(q=>q.id === ua.questionId)?.correctIndex === ua.selectedOptionIndex).length;
  const incorrectCount = userAnswers.filter(ua => ua.selectedOptionIndex !== null && questions.find(q=>q.id === ua.questionId)?.correctIndex !== ua.selectedOptionIndex).length;
  const unattemptedCount = userAnswers.filter(ua => ua.selectedOptionIndex === null).length;
  const filterCounts = { correct: correctCount, incorrect: incorrectCount, unattempted: unattemptedCount };

  if (filteredQuestionIds.length === 0 && (activeFilters.correct || activeFilters.incorrect || activeFilters.unattempted) && questions.length > 0) {
    return (
      <div className="max-w-6xl mx-auto p-4 text-center bg-white rounded-lg shadow-xl min-h-[calc(100vh-180px)] flex flex-col justify-center items-center">
        <ReviewTopBar
            quizTitle={quizTitle}
            currentLanguage={currentLanguage}
            showFilterDropdown={showFilterDropdown}
            setShowFilterDropdown={setShowFilterDropdown}
            activeFilters={activeFilters}
            toggleFilter={toggleFilter}
            resetFilters={resetFilters}
            filterCounts={filterCounts}
            onExitReview={onExitReview}
        />
        <p className="text-xl my-10 text-gray-700">No questions match your current filters.</p>
        <button onClick={onExitReview} className="mt-4 bg-primary text-white px-6 py-2.5 rounded-lg hover:bg-primary-dark transition-colors">
          Back to Quiz Summary
        </button>
      </div>
    );
  }
  if (!currentOriginalQuestion || !currentOriginalUserAnswer) {
      return (
           <div className="max-w-6xl mx-auto p-4 text-center bg-white rounded-lg shadow-xl min-h-[calc(100vh-180px)] flex flex-col justify-center items-center">
                <p className="text-xl text-gray-700">Quiz data is loading or no questions are available for review.</p>
                <button onClick={onExitReview} className="mt-6 bg-primary text-white px-6 py-2.5 rounded-lg hover:bg-primary-dark transition-colors">
                Back to Quiz Summary
                </button>
           </div>
      );
  }
  
  const questionStatusInfo = getQuestionStatus(currentOriginalQuestion, currentOriginalUserAnswer);

  return (
    <div className="flex flex-col max-h-[calc(100vh-40px)] md:max-h-[calc(100vh-60px)] overflow-hidden rounded-lg bg-white shadow-xl">
      <ReviewTopBar
        quizTitle={quizTitle} 
        currentLanguage={currentLanguage}
        showFilterDropdown={showFilterDropdown}
        setShowFilterDropdown={setShowFilterDropdown}
        activeFilters={activeFilters}
        toggleFilter={toggleFilter}
        resetFilters={resetFilters}
        filterCounts={filterCounts}
        onExitReview={onExitReview}
      />
      <div className="flex flex-1 overflow-hidden">
        {/* Left Pane (Question Details) */}
        <div className="flex-1 p-3 md:p-4 flex flex-col overflow-y-auto">
            <div className='mb-3 p-3 bg-blue-50 rounded-md border-l-4 border-primary-dark'>
                <div className="flex flex-wrap justify-between items-center text-sm text-gray-700 gap-x-4 gap-y-1">
                    <span className="font-medium">
                        Question {filteredQuestionIds.indexOf(currentOriginalQuestion.id) + 1} of {filteredQuestionIds.length} 
                        <span className="text-xs text-gray-500 ml-1">(Overall ID: {currentOriginalQuestion.id +1})</span>
                    </span>
                    <span className={`flex items-center font-medium ${questionStatusInfo.color}`}>{questionStatusInfo.icon} {questionStatusInfo.text}</span>
                </div>
            </div>

            <h3 className="text-md md:text-lg text-gray-800 mb-4 font-semibold leading-snug">{currentOriginalQuestion.text}</h3>
          
            <div className={`space-y-2.5 mb-5 ${!areOptionsVisible ? 'hidden' : ''}`}>
                {currentOriginalQuestion.options.map((option, index) => {
                const isTrueCorrect = index === currentOriginalQuestion.correctIndex;
                const originalUserSelectedThis = index === currentOriginalUserAnswer.selectedOptionIndex;
                let optionClasses = "w-full text-left p-3 border rounded-lg transition-colors duration-150 flex items-start justify-between text-sm";
                let reattemptFeedbackText = "";

                if (isReattemptModeOn) {
                    optionClasses += " cursor-pointer hover:bg-gray-100";
                    const reattemptedOptionForThisQ = reattemptAnswers[currentOriginalQuestion.id];

                    if (reattemptedOptionForThisQ === index) { 
                    if (isTrueCorrect) {
                        optionClasses += " bg-green-100 border-green-500 text-green-700 ring-1 ring-green-400 font-medium";
                        reattemptFeedbackText = "Congratulations! ✔️";
                    } else {
                        optionClasses += " bg-red-100 border-red-500 text-red-700 ring-1 ring-red-400 font-medium";
                        reattemptFeedbackText = "Next time... ❌";
                    }
                    } else if (reattemptedOptionForThisQ !== undefined && isTrueCorrect) {
                    optionClasses += " border-green-300 bg-green-50";
                    } else {
                    optionClasses += " border-gray-300 bg-white"; 
                    }
                } else { 
                    if (isTrueCorrect) optionClasses += " bg-green-100 border-green-400 text-green-700 font-medium";
                    else if (originalUserSelectedThis) optionClasses += " bg-red-100 border-red-400 text-red-700";
                    else optionClasses += " border-gray-300 bg-gray-50 text-gray-600";
                }

                return (
                    <button 
                        key={index} 
                        onClick={() => handleReattemptOptionSelect(index)} 
                        disabled={!isReattemptModeOn} 
                        className={optionClasses}
                        aria-pressed={isReattemptModeOn && reattemptAnswers[currentOriginalQuestion.id] === index}
                    >
                    <div className="flex items-start">
                        <span className={`font-semibold mr-2 ${isTrueCorrect && !isReattemptModeOn ? 'text-green-700' : (originalUserSelectedThis && !isTrueCorrect && !isReattemptModeOn ? 'text-red-700' : (isReattemptModeOn && reattemptAnswers[currentOriginalQuestion.id] === index ? (isTrueCorrect ? 'text-green-700' : 'text-red-700') : 'text-primary')) }`}>{String.fromCharCode(65 + index)}.</span>
                        <span>{option}</span>
                    </div>
                    {isReattemptModeOn && reattemptFeedbackText && (
                        <span className="text-xs font-semibold ml-2">{reattemptFeedbackText}</span>
                    )}
                    {!isReattemptModeOn && isTrueCorrect && <CheckCircleIcon className="w-5 h-5 text-green-600 flex-shrink-0 ml-2" />}
                    {!isReattemptModeOn && originalUserSelectedThis && !isTrueCorrect && <XCircleIcon className="w-5 h-5 text-red-600 flex-shrink-0 ml-2" />}
                    </button>
                );
                })}
            </div>

            <div className="flex flex-col sm:flex-row justify-between items-center gap-3 mb-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                <label className="flex items-center cursor-pointer">
                <input type="checkbox" checked={isReattemptModeOn} onChange={() => setIsReattemptModeOn(!isReattemptModeOn)} className="form-checkbox h-5 w-5 text-primary rounded focus:ring-primary-dark" />
                <span className="ml-2 text-sm font-medium text-gray-700">Re-attempt mode: <span className={isReattemptModeOn ? "font-semibold text-green-600" : "font-semibold text-red-600"}>{isReattemptModeOn ? 'ON' : 'OFF'}</span></span>
                </label>
                 <button 
                    onClick={() => setAreOptionsVisible(!areOptionsVisible)} 
                    className="flex items-center text-sm text-blue-600 hover:text-blue-700 font-medium py-1 px-3 rounded bg-blue-100 hover:bg-blue-200 transition"
                    title={areOptionsVisible ? 'Hide Options' : 'Show Options'}
                >
                    {areOptionsVisible ? <EyeSlashIcon className="w-4 h-4 mr-1.5" /> : <EyeIcon className="w-4 h-4 mr-1.5" />}
                    {areOptionsVisible ? 'Hide Options' : 'Show Options'}
                </button>
                <button onClick={() => setIsExplanationVisible(!isExplanationVisible)} className="flex items-center text-sm text-primary hover:text-primary-dark font-medium py-1 px-3 rounded bg-blue-100 hover:bg-blue-200 transition">
                    <EyeIcon className="w-4 h-4 mr-1.5" /> {isExplanationVisible ? 'Hide' : 'View'} Solution
                </button>
            </div>
            {isReattemptModeOn && <p className="text-xs text-center text-gray-600 mb-3 italic">Your original score will not be affected by re-attempts.</p>}
            
            {isExplanationVisible && (
                <div className="mt-4 p-4 bg-indigo-50 border-l-4 border-indigo-400 rounded-md animate-fadeIn">
                <h4 className="font-semibold text-gray-800 mb-2 flex items-center"><LightBulbIcon className="w-5 h-5 mr-2 text-indigo-500"/>Explanation</h4>
                <p className="text-sm text-gray-700 whitespace-pre-wrap">{currentOriginalQuestion.explanation}</p>
                </div>
            )}
            <div className="mt-auto pt-4 flex flex-col sm:flex-row justify-between items-center border-t border-gray-200">
                <button onClick={() => handleNavigate('prev')} disabled={currentQuestionDisplayIndex === 0 && filteredQuestionIds.length > 0} className="w-full sm:w-auto px-5 py-2.5 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center mb-2 sm:mb-0 transition-colors">
                <ChevronLeftIcon className="w-5 h-5 mr-1.5" /> Previous
                </button>
                
                <button onClick={() => handleNavigate('next')} disabled={(currentQuestionDisplayIndex >= filteredQuestionIds.length - 1) || filteredQuestionIds.length === 0} className="w-full sm:w-auto px-5 py-2.5 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center transition-colors">
                Next <ChevronRightIcon className="w-5 h-5 ml-1.5" />
                </button>
            </div>
        </div>

        <ReviewSidebar
          currentOriginalQuestion={currentOriginalQuestion}
          currentOriginalUserAnswer={currentOriginalUserAnswer}
          quizResults={quizResults}
          questions={questions}
          userAnswers={userAnswers}
          filteredQuestionIds={filteredQuestionIds}
          currentQuestionDisplayIndex={currentQuestionDisplayIndex}
          onPaginationClick={handlePaginationClick}
        />
      </div>
    </div>
  );
};

export default ReviewScreen;
